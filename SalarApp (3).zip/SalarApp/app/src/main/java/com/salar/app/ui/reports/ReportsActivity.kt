package com.salar.app.ui.reports

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.salar.app.calculation.MaterialCalculator
import com.salar.app.data.ProjectRepository
import com.salar.app.databinding.ActivityReportsBinding
import com.salar.app.drawing.CanvasMode
import com.salar.app.export.ExportManager
import com.salar.app.utils.Prefs
import kotlinx.coroutines.launch

class ReportsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReportsBinding
    private lateinit var repository: ProjectRepository
    private var projectId: Long = -1L
    private var projectName: String = "project"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = ProjectRepository(this)

        projectId = intent.getLongExtra("project_id", Prefs.getLastProject(this))
        if (projectId == -1L) { finish(); return }

        binding.exportDrawingView.mode = CanvasMode.STRUCTURE

        lifecycleScope.launch {
            val project = repository.getProject(projectId)
            projectName = project?.name ?: "project"
            binding.textReportsProjectName.text = projectName
            val model = repository.loadDrawing(projectId)
            binding.exportDrawingView.setModel(model)
        }

        binding.btnExportImage.setOnClickListener { exportImage() }
        binding.btnExportPdf.setOnClickListener { exportPdf() }
        binding.btnExportMaterialPdf.setOnClickListener { exportMaterialPdf() }
    }

    private fun exportImage() {
        binding.exportDrawingView.post {
            val file = ExportManager.exportViewAsImage(this, binding.exportDrawingView, "${projectName}_plan")
            Toast.makeText(this, file.name, Toast.LENGTH_SHORT).show()
            ExportManager.shareFile(this, file)
        }
    }

    private fun exportPdf() {
        binding.exportDrawingView.post {
            val file = ExportManager.exportViewAsPdf(this, binding.exportDrawingView, "${projectName}_plan", projectName)
            Toast.makeText(this, file.name, Toast.LENGTH_SHORT).show()
            ExportManager.shareFile(this, file)
        }
    }

    private fun exportMaterialPdf() {
        lifecycleScope.launch {
            val model = repository.loadDrawing(projectId)
            val settings = repository.getMaterialSettings(projectId)
            val calc = MaterialCalculator(settings)
            val result = calc.fromDrawing(model)
            val rows = ExportManager.quantityResultToRows(result)
            val file = ExportManager.exportMaterialReportPdf(this@ReportsActivity, projectName, "${projectName}_materials", rows)
            Toast.makeText(this@ReportsActivity, file.name, Toast.LENGTH_SHORT).show()
            ExportManager.shareFile(this@ReportsActivity, file)
        }
    }
}
