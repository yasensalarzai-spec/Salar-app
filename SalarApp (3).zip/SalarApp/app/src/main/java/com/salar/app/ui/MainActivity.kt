package com.salar.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.salar.app.databinding.ActivityMainBinding
import com.salar.app.ui.drawing.DrawingActivity
import com.salar.app.ui.electrical.ElectricalActivity
import com.salar.app.ui.materials.MaterialCalcActivity
import com.salar.app.ui.plumbing.PlumbingActivity
import com.salar.app.ui.project.NewProjectActivity
import com.salar.app.ui.project.ProjectListActivity
import com.salar.app.ui.reports.ReportsActivity
import com.salar.app.ui.settings.SettingsActivity
import com.salar.app.ui.threeD.ThreeDActivity

/**
 * سالار main menu. Every button here opens a real working screen -
 * none are placeholders (per project requirement #14).
 * 2D/3D/materials/electrical/plumbing open ProjectListActivity first if no
 * project has been used yet this session, since those screens need a project.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var lastOpenedProjectId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnNewProject.setOnClickListener {
            startActivity(Intent(this, NewProjectActivity::class.java))
        }
        binding.btnMyProjects.setOnClickListener {
            startActivity(Intent(this, ProjectListActivity::class.java))
        }
        binding.btn2D.setOnClickListener { openWithProject(DrawingActivity::class.java) }
        binding.btn3D.setOnClickListener { openWithProject(ThreeDActivity::class.java) }
        binding.btnMaterials.setOnClickListener { openWithProject(MaterialCalcActivity::class.java) }
        binding.btnElectrical.setOnClickListener { openWithProject(ElectricalActivity::class.java) }
        binding.btnPlumbing.setOnClickListener { openWithProject(PlumbingActivity::class.java) }
        binding.btnReports.setOnClickListener { openWithProject(ReportsActivity::class.java) }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun openWithProject(target: Class<*>) {
        val prefs = getSharedPreferences("salar_prefs", MODE_PRIVATE)
        val id = prefs.getLong("last_project_id", -1L)
        if (id == -1L) {
            // no project chosen yet this install -> send user to pick/create one first
            startActivity(Intent(this, ProjectListActivity::class.java).putExtra("target_after_pick", target.name))
        } else {
            startActivity(Intent(this, target).putExtra("project_id", id))
        }
    }
}
