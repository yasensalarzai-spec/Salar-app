package com.salar.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Editable material ratios/formulas per project, so quantities can be tuned
 * to local construction practice (requirement: "editable calculation formulas").
 * Cement:Sand:Aggregate ratio stored as parts (e.g. 1:2:4).
 */
@Entity(tableName = "material_settings")
data class MaterialSettingsEntity(
    @PrimaryKey val projectId: Long,
    val cementRatio: Float = 1f,
    val sandRatio: Float = 2f,
    val aggregateRatio: Float = 4f,
    val cementBagWeightKg: Float = 50f,
    val cementBagsPerM3DryMix: Float = 7.2f, // typical for 1:2:4, editable
    val dryVolumeFactor: Float = 1.54f,
    val blockLengthMM: Float = 400f,
    val blockHeightMM: Float = 200f,
    val blockThicknessMM: Float = 200f,
    val mortarAllowanceFactor: Float = 1.05f
)
