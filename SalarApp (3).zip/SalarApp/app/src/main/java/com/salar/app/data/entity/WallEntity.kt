package com.salar.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "walls")
data class WallEntity(
    @PrimaryKey val id: String,
    val projectId: Long,
    val floorIndex: Int,
    val x1: Float,
    val y1: Float,
    val x2: Float,
    val y2: Float,
    val thicknessMM: Float
)
