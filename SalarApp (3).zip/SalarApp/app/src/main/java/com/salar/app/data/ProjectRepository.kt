package com.salar.app.data

import android.content.Context
import com.salar.app.data.entity.*
import com.salar.app.model.*
import kotlinx.coroutines.flow.Flow

class ProjectRepository(context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val projectDao = db.projectDao()
    private val drawingDao = db.drawingDao()

    fun observeProjects(): Flow<List<ProjectEntity>> = projectDao.observeAll()

    suspend fun getProject(id: Long) = projectDao.getById(id)

    suspend fun createProject(name: String, clientName: String = "", location: String = ""): Long {
        return projectDao.insert(ProjectEntity(name = name, clientName = clientName, location = location))
    }

    suspend fun renameOrUpdate(project: ProjectEntity) {
        projectDao.update(project.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteProject(project: ProjectEntity) {
        projectDao.delete(project)
        drawingDao.clearWalls(project.id)
        drawingDao.clearOpenings(project.id)
        drawingDao.clearRooms(project.id)
        drawingDao.clearElectricalItems(project.id)
        drawingDao.clearWireRuns(project.id)
        drawingDao.clearPlumbingFixtures(project.id)
        drawingDao.clearPipeRuns(project.id)
    }

    /** Duplicate a project including its entire drawing (walls, MEP, materials). */
    suspend fun duplicateProject(source: ProjectEntity): Long {
        val newId = projectDao.insert(
            source.copy(id = 0, name = source.name + " - Copy", createdAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis())
        )
        val model = loadDrawing(source.id)
        saveDrawing(newId, model)
        drawingDao.getMaterialSettings(source.id)?.let {
            drawingDao.upsertMaterialSettings(it.copy(projectId = newId))
        }
        return newId
    }

    // ---------------- Drawing persistence ----------------

    suspend fun loadDrawing(projectId: Long): DrawingModel {
        val model = DrawingModel()
        model.walls.addAll(drawingDao.getWalls(projectId).map {
            Wall(it.id, PointMM(it.x1, it.y1), PointMM(it.x2, it.y2), it.thicknessMM, it.floorIndex)
        })
        model.openings.addAll(drawingDao.getOpenings(projectId).map {
            Opening(it.id, it.wallId, it.offsetMM, it.widthMM, it.isDoor, it.heightMM, it.sillHeightMM)
        })
        model.rooms.addAll(drawingDao.getRooms(projectId).map {
            RoomFace(it.id, it.name, parsePoints(it.polygon), it.floorIndex)
        })
        model.electricalItems.addAll(drawingDao.getElectricalItems(projectId).map {
            ElectricalItem(it.id, ElectricalType.valueOf(it.type), PointMM(it.x, it.y), it.floorIndex)
        })
        model.wireRuns.addAll(drawingDao.getWireRuns(projectId).map {
            WireRun(it.id, parsePoints(it.points).toMutableList(), it.floorIndex)
        })
        model.plumbingFixtures.addAll(drawingDao.getPlumbingFixtures(projectId).map {
            PlumbingFixture(it.id, PlumbingType.valueOf(it.type), PointMM(it.x, it.y), it.floorIndex)
        })
        model.pipeRuns.addAll(drawingDao.getPipeRuns(projectId).map {
            PipeRun(it.id, PlumbingType.valueOf(it.type), it.diameterMM, parsePoints(it.points).toMutableList(), it.floorIndex)
        })
        val project = projectDao.getById(projectId)
        model.floorCount = project?.floorCount ?: 1
        return model
    }

    suspend fun saveDrawing(projectId: Long, model: DrawingModel) {
        drawingDao.clearWalls(projectId)
        drawingDao.insertWalls(model.walls.map {
            WallEntity(it.id, projectId, it.floorIndex, it.start.x, it.start.y, it.end.x, it.end.y, it.thicknessMM)
        })

        drawingDao.clearOpenings(projectId)
        drawingDao.insertOpenings(model.openings.map {
            OpeningEntity(it.id, projectId, it.wallId, it.offsetMM, it.widthMM, it.isDoor, it.heightMM, it.sillHeightMM)
        })

        drawingDao.clearRooms(projectId)
        drawingDao.insertRooms(model.rooms.map {
            RoomFaceEntity(it.id, projectId, it.floorIndex, it.name, formatPoints(it.polygon))
        })

        drawingDao.clearElectricalItems(projectId)
        drawingDao.insertElectricalItems(model.electricalItems.map {
            ElectricalItemEntity(it.id, projectId, it.floorIndex, it.type.name, it.point.x, it.point.y)
        })

        drawingDao.clearWireRuns(projectId)
        drawingDao.insertWireRuns(model.wireRuns.map {
            WireRunEntity(it.id, projectId, it.floorIndex, formatPoints(it.points))
        })

        drawingDao.clearPlumbingFixtures(projectId)
        drawingDao.insertPlumbingFixtures(model.plumbingFixtures.map {
            PlumbingFixtureEntity(it.id, projectId, it.floorIndex, it.type.name, it.point.x, it.point.y)
        })

        drawingDao.clearPipeRuns(projectId)
        drawingDao.insertPipeRuns(model.pipeRuns.map {
            PipeRunEntity(it.id, projectId, it.floorIndex, it.type.name, it.diameterMM, formatPoints(it.points))
        })

        projectDao.getById(projectId)?.let {
            projectDao.update(it.copy(floorCount = model.floorCount, updatedAt = System.currentTimeMillis()))
        }
    }

    suspend fun getMaterialSettings(projectId: Long): MaterialSettingsEntity {
        return drawingDao.getMaterialSettings(projectId) ?: MaterialSettingsEntity(projectId = projectId)
    }

    suspend fun saveMaterialSettings(settings: MaterialSettingsEntity) {
        drawingDao.upsertMaterialSettings(settings)
    }

    private fun formatPoints(points: List<PointMM>): String =
        points.joinToString(";") { "${it.x},${it.y}" }

    private fun parsePoints(s: String): List<PointMM> {
        if (s.isBlank()) return emptyList()
        return s.split(";").mapNotNull {
            val parts = it.split(",")
            if (parts.size == 2) PointMM(parts[0].toFloat(), parts[1].toFloat()) else null
        }
    }
}
