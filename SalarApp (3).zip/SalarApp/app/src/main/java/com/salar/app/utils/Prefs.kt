package com.salar.app.utils

import android.content.Context

object Prefs {
    private const val NAME = "salar_prefs"

    fun setLastProject(context: Context, id: Long) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putLong("last_project_id", id).apply()
    }

    fun getLastProject(context: Context): Long =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE).getLong("last_project_id", -1L)

    fun setUnit(context: Context, unit: String) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putString("unit", unit).apply()
    }

    fun getUnit(context: Context): String =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString("unit", "M") ?: "M"

    fun setDefaultWallThickness(context: Context, mm: Float) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putFloat("wall_thickness", mm).apply()
    }

    fun getDefaultWallThickness(context: Context): Float =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE).getFloat("wall_thickness", 200f)
}
