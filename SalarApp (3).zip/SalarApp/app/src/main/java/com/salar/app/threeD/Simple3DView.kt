package com.salar.app.threeD

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.salar.app.model.DrawingModel
import com.salar.app.model.PointMM
import kotlin.math.cos
import kotlin.math.sin

/**
 * A lightweight, dependency-free 3D preview: every wall is extruded upward by
 * [wallHeightMM] into a box, then projected with a rotating isometric camera
 * and rendered back-to-front (painter's algorithm) using the Canvas API.
 * This intentionally avoids OpenGL/Filament so the app stays small, fast on
 * low-end phones, and easy to extend later with a real 3D engine if desired.
 */
class Simple3DView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    var wallHeightMM: Float = 3000f
        set(value) { field = value; invalidate() }

    private var model: DrawingModel = DrawingModel()
    fun setModel(m: DrawingModel) { model = m; invalidate() }

    private var rotationY = -35.0
    private var rotationX = 25.0
    private var zoom = 1f
    private var lastX = 0f
    private var lastY = 0f

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            zoom = (zoom * detector.scaleFactor).coerceIn(0.2f, 4f)
            invalidate()
            return true
        }
    })

    private val wallPaintTop = Paint().apply { color = Color.parseColor("#2B2B2B"); style = Paint.Style.FILL; isAntiAlias = true }
    private val wallPaintSide = Paint().apply { color = Color.parseColor("#1A1A1A"); style = Paint.Style.FILL; isAntiAlias = true }
    private val wallPaintFront = Paint().apply { color = Color.parseColor("#C62828"); style = Paint.Style.FILL; isAntiAlias = true }
    private val outlinePaint = Paint().apply { color = Color.parseColor("#000000"); style = Paint.Style.STROKE; strokeWidth = 2f; isAntiAlias = true }
    private val groundPaint = Paint().apply { color = Color.parseColor("#EFEFEF"); style = Paint.Style.FILL }

    data class Point3(val x: Double, val y: Double, val z: Double)

    private fun project(p: Point3): PointF {
        val ry = Math.toRadians(rotationY)
        val rx = Math.toRadians(rotationX)

        // rotate around Y (vertical) axis
        var x = p.x * cos(ry) - p.z * sin(ry)
        var z = p.x * sin(ry) + p.z * cos(ry)
        var y = p.y

        // rotate around X axis (tilt)
        val y2 = y * cos(rx) - z * sin(rx)
        val z2 = y * sin(rx) + z * cos(rx)
        y = y2; z = z2

        val scaleFactor = 0.00025 * zoom * (width.coerceAtLeast(1))
        val screenX = width / 2f + (x * scaleFactor).toFloat()
        val screenY = height / 2f - (y * scaleFactor).toFloat() + (z * scaleFactor * 0.35).toFloat()
        return PointF(screenX, screenY)
    }

    private fun depthOf(p: Point3): Double {
        val ry = Math.toRadians(rotationY)
        return p.x * sin(ry) + p.z * cos(ry)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.parseColor("#FAFAFA"))
        canvas.drawRect(0f, height * 0.55f, width.toFloat(), height.toFloat(), groundPaint)

        data class Quad(val pts: List<Point3>, val paint: Paint, val depth: Double)

        val quads = mutableListOf<Quad>()
        val walls = model.wallsOnFloor(model.activeFloor)
        // recenter model so building rotates around its own middle
        val cx = if (walls.isNotEmpty()) walls.flatMap { listOf(it.start.x, it.end.x) }.average() else 0.0
        val cz = if (walls.isNotEmpty()) walls.flatMap { listOf(it.start.y, it.end.y) }.average() else 0.0

        for (wall in walls) {
            val dx = (wall.end.x - wall.start.x).toDouble()
            val dz = (wall.end.y - wall.start.y).toDouble()
            val len = kotlin.math.hypot(dx, dz).coerceAtLeast(1.0)
            val nx = -dz / len * (wall.thicknessMM / 2.0)
            val nz = dx / len * (wall.thicknessMM / 2.0)

            val sx = wall.start.x - cx; val sz = wall.start.y - cz
            val ex = wall.end.x - cx; val ez = wall.end.y - cz

            val base = listOf(
                Point3(sx + nx, 0.0, sz + nz),
                Point3(ex + nx, 0.0, ez + nz),
                Point3(ex - nx, 0.0, ez - nz),
                Point3(sx - nx, 0.0, sz - nz)
            )
            val top = base.map { Point3(it.x, wallHeightMM.toDouble(), it.z) }

            // top face
            quads.add(Quad(top, wallPaintTop, top.sumOf { depthOf(it) } / 4))
            // 4 side faces
            for (i in 0 until 4) {
                val j = (i + 1) % 4
                val face = listOf(base[i], base[j], top[j], top[i])
                val avgDepth = face.sumOf { depthOf(it) } / 4
                quads.add(Quad(face, wallPaintSide, avgDepth))
            }
        }

        // painter's algorithm: draw farthest first
        quads.sortByDescending { it.depth }
        for (q in quads) {
            val path = Path()
            val pts = q.pts.map { project(it) }
            path.moveTo(pts[0].x, pts[0].y)
            for (i in 1 until pts.size) path.lineTo(pts[i].x, pts[i].y)
            path.close()
            canvas.drawPath(path, q.paint)
            canvas.drawPath(path, outlinePaint)
        }

        if (walls.isEmpty()) {
            val msg = Paint().apply { color = Color.GRAY; textSize = 36f; textAlign = Paint.Align.CENTER }
            canvas.drawText("لومړی 2D نقشه جوړه کړئ", width / 2f, height / 2f, msg)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        if (scaleDetector.isInProgress) return true

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastX = event.x; lastY = event.y }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 1) {
                    val dx = event.x - lastX
                    val dy = event.y - lastY
                    rotationY += dx * 0.4
                    rotationX = (rotationX - dy * 0.3).coerceIn(-80.0, 80.0)
                    lastX = event.x
                    lastY = event.y
                    invalidate()
                }
            }
        }
        return true
    }
}
