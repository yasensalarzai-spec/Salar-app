package com.salar.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** A detected/named room. Polygon points are serialized as "x1,y1;x2,y2;..." in mm. */
@Entity(tableName = "room_faces")
data class RoomFaceEntity(
    @PrimaryKey val id: String,
    val projectId: Long,
    val floorIndex: Int,
    val name: String,
    val polygon: String
)
