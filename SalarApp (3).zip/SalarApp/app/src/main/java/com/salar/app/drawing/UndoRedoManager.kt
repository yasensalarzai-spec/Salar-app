package com.salar.app.drawing

import com.salar.app.model.DrawingModel

/**
 * Simple snapshot-based undo/redo. The drawing model for a residential plan
 * is small (tens to low hundreds of elements) so snapshotting on every
 * completed action is cheap and far more robust than diffing.
 */
class UndoRedoManager(initial: DrawingModel, private val maxHistory: Int = 40) {
    private val undoStack = ArrayDeque<DrawingModel>()
    private val redoStack = ArrayDeque<DrawingModel>()
    private var current: DrawingModel = initial

    fun current(): DrawingModel = current

    /** Call after a completed user action (wall placed, door added, item deleted, etc). */
    fun push(newState: DrawingModel) {
        undoStack.addLast(current)
        if (undoStack.size > maxHistory) undoStack.removeFirst()
        current = newState
        redoStack.clear()
    }

    fun canUndo() = undoStack.isNotEmpty()
    fun canRedo() = redoStack.isNotEmpty()

    fun undo(): DrawingModel {
        if (undoStack.isEmpty()) return current
        redoStack.addLast(current)
        current = undoStack.removeLast()
        return current
    }

    fun redo(): DrawingModel {
        if (redoStack.isEmpty()) return current
        undoStack.addLast(current)
        current = redoStack.removeLast()
        return current
    }
}
