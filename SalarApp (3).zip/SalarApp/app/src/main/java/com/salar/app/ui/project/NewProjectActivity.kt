package com.salar.app.ui.project

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.salar.app.R
import com.salar.app.data.ProjectRepository
import com.salar.app.databinding.ActivityNewProjectBinding
import com.salar.app.ui.drawing.DrawingActivity
import com.salar.app.utils.Prefs
import kotlinx.coroutines.launch

class NewProjectActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNewProjectBinding
    private lateinit var repository: ProjectRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewProjectBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = ProjectRepository(this)

        binding.btnCancel.setOnClickListener { finish() }
        binding.btnCreate.setOnClickListener { createProject() }
    }

    private fun createProject() {
        val name = binding.editProjectName.text.toString().trim()
        if (name.isEmpty()) {
            Toast.makeText(this, getString(R.string.project_name_hint), Toast.LENGTH_SHORT).show()
            return
        }
        val client = binding.editClientName.text.toString().trim()
        val location = binding.editLocation.text.toString().trim()

        lifecycleScope.launch {
            val id = repository.createProject(name, client, location)
            Prefs.setLastProject(this@NewProjectActivity, id)
            startActivity(
                android.content.Intent(this@NewProjectActivity, DrawingActivity::class.java)
                    .putExtra("project_id", id)
            )
            finish()
        }
    }
}
