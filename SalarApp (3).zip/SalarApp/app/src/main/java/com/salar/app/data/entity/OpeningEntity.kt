package com.salar.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "openings")
data class OpeningEntity(
    @PrimaryKey val id: String,
    val projectId: Long,
    val wallId: String,
    val offsetMM: Float,
    val widthMM: Float,
    val isDoor: Boolean,
    val heightMM: Float,
    val sillHeightMM: Float
)
