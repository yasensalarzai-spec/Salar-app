package com.salar.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "electrical_items")
data class ElectricalItemEntity(
    @PrimaryKey val id: String,
    val projectId: Long,
    val floorIndex: Int,
    val type: String,
    val x: Float,
    val y: Float
)

@Entity(tableName = "wire_runs")
data class WireRunEntity(
    @PrimaryKey val id: String,
    val projectId: Long,
    val floorIndex: Int,
    val points: String // "x1,y1;x2,y2;..."
)
