package com.salar.app.ui.project

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.salar.app.data.entity.ProjectEntity
import com.salar.app.databinding.ItemProjectBinding
import java.text.SimpleDateFormat
import java.util.*

class ProjectAdapter(
    private val onOpen: (ProjectEntity) -> Unit,
    private val onDuplicate: (ProjectEntity) -> Unit,
    private val onDelete: (ProjectEntity) -> Unit
) : RecyclerView.Adapter<ProjectAdapter.VH>() {

    private val items = mutableListOf<ProjectEntity>()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

    fun submitList(list: List<ProjectEntity>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    inner class VH(val binding: ItemProjectBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemProjectBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val project = items[position]
        holder.binding.textProjectName.text = project.name
        val metaParts = mutableListOf<String>()
        if (project.clientName.isNotBlank()) metaParts.add(project.clientName)
        if (project.location.isNotBlank()) metaParts.add(project.location)
        metaParts.add(dateFormat.format(Date(project.updatedAt)))
        holder.binding.textProjectMeta.text = metaParts.joinToString(" • ")

        holder.binding.btnOpen.setOnClickListener { onOpen(project) }
        holder.binding.btnDuplicate.setOnClickListener { onDuplicate(project) }
        holder.binding.btnDelete.setOnClickListener { onDelete(project) }
    }

    override fun getItemCount() = items.size
}
