package com.salar.app.drawing

import com.salar.app.model.PointMM
import com.salar.app.model.RoomFace
import com.salar.app.model.Wall
import kotlin.math.atan2
import kotlin.math.abs

/**
 * Geometry helpers used by the 2D drawing engine:
 *  - point/wall snapping while drawing
 *  - automatic room (closed polygon) detection from a set of walls, using
 *    planar-graph face tracing so the user never has to manually outline a
 *    room: as soon as walls form a closed loop, its area is computed.
 */
object Geometry {

    /** Snap [p] to the nearest wall endpoint or wall line within [toleranceMM], else return [p]. */
    fun snapPoint(p: PointMM, walls: List<Wall>, toleranceMM: Float = 150f): PointMM {
        var best: PointMM? = null
        var bestDist = toleranceMM

        for (w in walls) {
            for (endpoint in listOf(w.start, w.end)) {
                val d = p.distanceTo(endpoint)
                if (d < bestDist) {
                    bestDist = d
                    best = endpoint
                }
            }
        }
        if (best != null) return best

        // Snap onto the nearest wall's line (perpendicular projection) if close enough.
        for (w in walls) {
            val proj = projectOntoSegment(p, w.start, w.end)
            val d = p.distanceTo(proj)
            if (d < bestDist) {
                bestDist = d
                best = proj
            }
        }
        return best ?: p
    }

    /** Snap an angle to the nearest 15 degree increment (for straight/diagonal wall drawing). */
    fun snapAngle(from: PointMM, to: PointMM, stepDegrees: Double = 15.0): PointMM {
        val dx = (to.x - from.x).toDouble()
        val dy = (to.y - from.y).toDouble()
        val length = kotlin.math.sqrt(dx * dx + dy * dy)
        if (length < 1.0) return to
        var angle = Math.toDegrees(atan2(dy, dx))
        angle = Math.round(angle / stepDegrees) * stepDegrees
        val rad = Math.toRadians(angle)
        return PointMM(
            (from.x + length * kotlin.math.cos(rad)).toFloat(),
            (from.y + length * kotlin.math.sin(rad)).toFloat()
        )
    }

    private fun projectOntoSegment(p: PointMM, a: PointMM, b: PointMM): PointMM {
        val abx = b.x - a.x
        val aby = b.y - a.y
        val lenSq = abx * abx + aby * aby
        if (lenSq < 1e-6) return a
        var t = ((p.x - a.x) * abx + (p.y - a.y) * aby) / lenSq
        t = t.coerceIn(0f, 1f)
        return PointMM(a.x + t * abx, a.y + t * aby)
    }

    /**
     * Detect closed rooms formed by [walls] on a given floor using planar face
     * tracing. Walls must share exact endpoint coordinates to be considered
     * connected (the drawing view guarantees this via [snapPoint]).
     * Returns one RoomFace per bounded face (the single unbounded outer face
     * is excluded automatically).
     */
    fun detectRooms(walls: List<Wall>, floorIndex: Int): List<RoomFace> {
        if (walls.size < 3) return emptyList()

        // Build a node list of unique points (snap-merged) and adjacency per node,
        // each adjacency entry sorted by angle for face tracing.
        val nodeKey = { p: PointMM -> "${Math.round(p.x)}_${Math.round(p.y)}" }
        val nodePoints = LinkedHashMap<String, PointMM>()
        for (w in walls) {
            nodePoints[nodeKey(w.start)] = w.start
            nodePoints[nodeKey(w.end)] = w.end
        }

        // directed edges: for each undirected wall we have two directed half-edges
        data class HalfEdge(val fromKey: String, val toKey: String)
        val halfEdges = mutableListOf<HalfEdge>()
        for (w in walls) {
            val a = nodeKey(w.start)
            val b = nodeKey(w.end)
            if (a == b) continue
            halfEdges.add(HalfEdge(a, b))
            halfEdges.add(HalfEdge(b, a))
        }

        // adjacency: for each node, list of neighbor keys sorted by angle (ascending)
        val adjacency = HashMap<String, MutableList<String>>()
        for (he in halfEdges) {
            adjacency.getOrPut(he.fromKey) { mutableListOf() }.add(he.toKey)
        }
        for ((key, neighbors) in adjacency) {
            val origin = nodePoints[key]!!
            neighbors.sortBy { nk -> atan2((nodePoints[nk]!!.y - origin.y).toDouble(), (nodePoints[nk]!!.x - origin.x).toDouble()) }
        }

        val visited = HashSet<Pair<String, String>>()
        val faces = mutableListOf<List<String>>()

        for (he in halfEdges) {
            val startPair = he.fromKey to he.toKey
            if (visited.contains(startPair)) continue

            val face = mutableListOf<String>()
            var curFrom = he.fromKey
            var curTo = he.toKey
            var guard = 0
            while (guard < 500) {
                guard++
                visited.add(curFrom to curTo)
                face.add(curFrom)

                val neighbors = adjacency[curTo] ?: break
                // Find reverse edge (curTo -> curFrom) in the sorted neighbor list,
                // then take the NEXT neighbor clockwise from it - this traces the
                // boundary of the face to the right of the current directed edge.
                val reverseIdx = neighbors.indexOf(curFrom)
                if (reverseIdx == -1) break
                val nextIdx = (reverseIdx - 1 + neighbors.size) % neighbors.size
                val nextTo = neighbors[nextIdx]

                val nextFrom = curTo
                if (nextFrom == he.fromKey && nextTo == he.toKey) break // closed the loop
                curFrom = nextFrom
                curTo = nextTo
                if (curFrom == he.fromKey && curTo == he.toKey) break
            }
            if (face.size >= 3) faces.add(face)
        }

        // Convert faces to polygons, compute signed area, drop the outer face
        // (the one with the largest absolute area is the unbounded outside).
        val candidateRooms = faces.mapNotNull { face ->
            val poly = face.map { nodePoints[it]!! }
            val signed = signedArea(poly)
            if (abs(signed) < 1e-3) null else Pair(poly, signed)
        }
        if (candidateRooms.isEmpty()) return emptyList()

        val maxAbs = candidateRooms.maxOf { abs(it.second) }
        return candidateRooms
            .filter { abs(it.second) < maxAbs - 1e-3 || candidateRooms.size == 1 }
            .distinctBy { poly -> poly.first.map { nodeKey(it) }.sorted() }
            .map { RoomFace(polygon = it.first, floorIndex = floorIndex) }
    }

    private fun signedArea(poly: List<PointMM>): Double {
        var sum = 0.0
        val n = poly.size
        for (i in 0 until n) {
            val p1 = poly[i]
            val p2 = poly[(i + 1) % n]
            sum += (p1.x.toDouble() * p2.y.toDouble()) - (p2.x.toDouble() * p1.y.toDouble())
        }
        return sum / 2.0
    }
}
