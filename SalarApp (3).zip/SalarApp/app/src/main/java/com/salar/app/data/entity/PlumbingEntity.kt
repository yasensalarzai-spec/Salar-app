package com.salar.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "plumbing_fixtures")
data class PlumbingFixtureEntity(
    @PrimaryKey val id: String,
    val projectId: Long,
    val floorIndex: Int,
    val type: String,
    val x: Float,
    val y: Float
)

@Entity(tableName = "pipe_runs")
data class PipeRunEntity(
    @PrimaryKey val id: String,
    val projectId: Long,
    val floorIndex: Int,
    val type: String,
    val diameterMM: Float,
    val points: String
)
