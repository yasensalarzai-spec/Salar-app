package com.salar.app.ui.electrical

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.salar.app.R
import com.salar.app.data.ProjectRepository
import com.salar.app.databinding.ActivityElectricalBinding
import com.salar.app.drawing.CanvasMode
import com.salar.app.drawing.DrawingViewListener
import com.salar.app.drawing.ElectricalTool
import com.salar.app.model.ElectricalType
import com.salar.app.utils.DisplayUnit
import com.salar.app.utils.Prefs
import com.salar.app.utils.UnitConverter
import kotlinx.coroutines.launch

/**
 * Electrical overlay: draws lights/switches/sockets/panel + wire runs directly
 * on top of the same walls drawn in the 2D structure screen.
 */
class ElectricalActivity : AppCompatActivity() {

    private lateinit var binding: ActivityElectricalBinding
    private lateinit var repository: ProjectRepository
    private var projectId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityElectricalBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = ProjectRepository(this)

        projectId = intent.getLongExtra("project_id", Prefs.getLastProject(this))
        if (projectId == -1L) { finish(); return }

        binding.drawingViewElec.mode = CanvasMode.ELECTRICAL
        binding.drawingViewElec.displayUnit = DisplayUnit.valueOf(Prefs.getUnit(this))
        binding.drawingViewElec.listener = object : DrawingViewListener {
            override fun onModelChanged() { updateSummary() }
        }

        binding.toolLight.setOnClickListener { select(ElectricalTool.LIGHT) }
        binding.toolSwitch.setOnClickListener { select(ElectricalTool.SWITCH) }
        binding.toolSocket.setOnClickListener { select(ElectricalTool.SOCKET) }
        binding.toolPanel.setOnClickListener { select(ElectricalTool.PANEL) }
        binding.toolWire.setOnClickListener { select(ElectricalTool.WIRE) }
        binding.toolElecDelete.setOnClickListener { select(ElectricalTool.DELETE) }
        binding.toolFinish.setOnClickListener {
            // finishing a wire run is also achieved with a double-tap on canvas;
            // this button re-selects the wire tool so the user can start a new run.
            select(ElectricalTool.WIRE)
        }
        binding.toolElecSave.setOnClickListener { saveProject() }

        lifecycleScope.launch {
            val project = repository.getProject(projectId)
            binding.textProjectTitleElec.text = project?.name ?: ""
            val model = repository.loadDrawing(projectId)
            binding.drawingViewElec.setModel(model)
            updateSummary()
        }
    }

    private fun select(tool: ElectricalTool) {
        binding.drawingViewElec.electricalTool = tool
    }

    private fun updateSummary() {
        val model = binding.drawingViewElec.getModel()
        val floor = model.activeFloor
        val lights = model.electricalItems.count { it.floorIndex == floor && it.type == ElectricalType.LIGHT }
        val switches = model.electricalItems.count { it.floorIndex == floor && it.type == ElectricalType.SWITCH }
        val sockets = model.electricalItems.count { it.floorIndex == floor && it.type == ElectricalType.SOCKET }
        val wireLengthMM = model.wireRuns.filter { it.floorIndex == floor }.sumOf { it.lengthMM().toDouble() }.toFloat()
        binding.textElecSummary.text = getString(
            R.string.elec_summary, lights, switches, sockets,
            UnitConverter.formatMM(wireLengthMM, binding.drawingViewElec.displayUnit)
        )
    }

    private fun saveProject() {
        lifecycleScope.launch { repository.saveDrawing(projectId, binding.drawingViewElec.getModel()) }
    }

    override fun onPause() {
        super.onPause()
        saveProject()
    }
}
