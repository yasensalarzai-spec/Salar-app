package com.salar.app.drawing

interface DrawingViewListener {
    fun onHistoryChanged(canUndo: Boolean, canRedo: Boolean) {}
    fun onSelectionInfo(text: String?) {}
    /** Fired right after a wall is finished being drawn, so the host can offer an "exact length" dialog. */
    fun onWallDrawn(wallId: String, lengthMM: Float) {}
    fun onModelChanged() {}
}
