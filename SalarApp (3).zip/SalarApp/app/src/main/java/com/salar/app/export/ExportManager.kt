package com.salar.app.export

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.view.View
import androidx.core.content.FileProvider
import com.salar.app.calculation.QuantityResult
import java.io.File
import java.io.FileOutputStream

/**
 * Everything here writes to the app's own external-files "exports" folder
 * (no INTERNET permission needed) and hands the resulting file to the
 * Android share sheet via FileProvider, satisfying "export + share locally".
 */
object ExportManager {

    private fun exportsDir(context: Context): File {
        val dir = File(context.getExternalFilesDir(null), "exports")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun exportViewAsImage(context: Context, view: View, fileName: String): File {
        val bitmap = Bitmap.createBitmap(view.width.coerceAtLeast(1), view.height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        view.draw(canvas)
        val file = File(exportsDir(context), "$fileName.png")
        FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out) }
        return file
    }

    fun exportViewAsPdf(context: Context, view: View, fileName: String, title: String): File {
        val document = PdfDocument()
        val pageWidth = view.width.coerceAtLeast(1)
        val pageHeight = view.height.coerceAtLeast(1) + 80
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        canvas.drawColor(Color.WHITE)
        val titlePaint = Paint().apply { color = Color.BLACK; textSize = 28f; isFakeBoldText = true }
        canvas.drawText(title, 20f, 40f, titlePaint)
        canvas.save()
        canvas.translate(0f, 60f)
        view.draw(canvas)
        canvas.restore()

        document.finishPage(page)
        val file = File(exportsDir(context), "$fileName.pdf")
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()
        return file
    }

    /** Text-based PDF report for material/quantity results - no drawing view needed. */
    fun exportMaterialReportPdf(
        context: Context,
        projectName: String,
        fileName: String,
        rows: List<Pair<String, String>>
    ): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(842, 1190, 1).create() // A4 at 72dpi*~1.4 (portrait-ish)
        val page = document.startPage(pageInfo)
        val canvas = page.canvas
        canvas.drawColor(Color.WHITE)

        val titlePaint = Paint().apply { color = Color.parseColor("#C62828"); textSize = 30f; isFakeBoldText = true }
        val headerPaint = Paint().apply { color = Color.BLACK; textSize = 20f; isFakeBoldText = true }
        val labelPaint = Paint().apply { color = Color.DKGRAY; textSize = 18f }
        val valuePaint = Paint().apply { color = Color.BLACK; textSize = 18f; isFakeBoldText = true }
        val linePaint = Paint().apply { color = Color.LTGRAY; strokeWidth = 1f }

        canvas.drawText("سالار - د مواد راپور", 40f, 50f, titlePaint)
        canvas.drawText("Project: $projectName", 40f, 85f, headerPaint)

        var y = 130f
        for ((label, value) in rows) {
            canvas.drawText(label, 40f, y, labelPaint)
            canvas.drawText(value, 500f, y, valuePaint)
            canvas.drawLine(40f, y + 12f, 800f, y + 12f, linePaint)
            y += 42f
        }

        document.finishPage(page)
        val file = File(exportsDir(context), "$fileName.pdf")
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()
        return file
    }

    fun quantityResultToRows(result: QuantityResult): List<Pair<String, String>> = listOf(
        "Net wall area (net wall area m2)" to String.format("%.2f m²", result.netWallAreaM2),
        "Wall volume (wall volume m3)" to String.format("%.2f m³", result.wallVolumeM3),
        "Block/brick quantity" to "${result.blockCount} pcs",
        "Concrete volume" to String.format("%.2f m³", result.concreteVolumeM3),
        "Cement" to String.format("%.1f bags", result.cementBags),
        "Sand" to String.format("%.2f m³", result.sandM3),
        "Aggregate" to String.format("%.2f m³", result.aggregateM3)
    )

    fun shareFile(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "com.salar.app.fileprovider", file)
        val mime = if (file.extension == "pdf") "application/pdf" else "image/png"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "شریکول"))
    }
}
