package com.salar.app.ui.threeD

import android.os.Bundle
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.salar.app.data.ProjectRepository
import com.salar.app.databinding.Activity3dBinding
import com.salar.app.utils.Prefs
import kotlinx.coroutines.launch

class ThreeDActivity : AppCompatActivity() {

    private lateinit var binding: Activity3dBinding
    private lateinit var repository: ProjectRepository
    private var projectId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = Activity3dBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = ProjectRepository(this)

        projectId = intent.getLongExtra("project_id", Prefs.getLastProject(this))
        if (projectId == -1L) { finish(); return }

        binding.seekHeight.progress = binding.view3d.wallHeightMM.toInt()
        updateHeightLabel(binding.view3d.wallHeightMM)
        binding.seekHeight.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val height = progress.coerceAtLeast(1500).toFloat()
                binding.view3d.wallHeightMM = height
                updateHeightLabel(height)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.btnBackTo2D.setOnClickListener { finish() }

        lifecycleScope.launch {
            val project = repository.getProject(projectId)
            binding.textProjectTitle3d.text = project?.name ?: ""
            val model = repository.loadDrawing(projectId)
            binding.view3d.setModel(model)
        }
    }

    private fun updateHeightLabel(mm: Float) {
        binding.textHeightValue.text = String.format("%.1f m", mm / 1000f)
    }
}
