package com.salar.app.data.dao

import androidx.room.*
import com.salar.app.data.entity.*

@Dao
interface DrawingDao {

    // ---- Walls ----
    @Query("SELECT * FROM walls WHERE projectId = :projectId")
    suspend fun getWalls(projectId: Long): List<WallEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWalls(walls: List<WallEntity>)

    @Query("DELETE FROM walls WHERE projectId = :projectId")
    suspend fun clearWalls(projectId: Long)

    // ---- Openings (doors/windows) ----
    @Query("SELECT * FROM openings WHERE projectId = :projectId")
    suspend fun getOpenings(projectId: Long): List<OpeningEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOpenings(openings: List<OpeningEntity>)

    @Query("DELETE FROM openings WHERE projectId = :projectId")
    suspend fun clearOpenings(projectId: Long)

    // ---- Rooms ----
    @Query("SELECT * FROM room_faces WHERE projectId = :projectId")
    suspend fun getRooms(projectId: Long): List<RoomFaceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRooms(rooms: List<RoomFaceEntity>)

    @Query("DELETE FROM room_faces WHERE projectId = :projectId")
    suspend fun clearRooms(projectId: Long)

    // ---- Electrical ----
    @Query("SELECT * FROM electrical_items WHERE projectId = :projectId")
    suspend fun getElectricalItems(projectId: Long): List<ElectricalItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertElectricalItems(items: List<ElectricalItemEntity>)

    @Query("DELETE FROM electrical_items WHERE projectId = :projectId")
    suspend fun clearElectricalItems(projectId: Long)

    @Query("SELECT * FROM wire_runs WHERE projectId = :projectId")
    suspend fun getWireRuns(projectId: Long): List<WireRunEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWireRuns(runs: List<WireRunEntity>)

    @Query("DELETE FROM wire_runs WHERE projectId = :projectId")
    suspend fun clearWireRuns(projectId: Long)

    // ---- Plumbing ----
    @Query("SELECT * FROM plumbing_fixtures WHERE projectId = :projectId")
    suspend fun getPlumbingFixtures(projectId: Long): List<PlumbingFixtureEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlumbingFixtures(items: List<PlumbingFixtureEntity>)

    @Query("DELETE FROM plumbing_fixtures WHERE projectId = :projectId")
    suspend fun clearPlumbingFixtures(projectId: Long)

    @Query("SELECT * FROM pipe_runs WHERE projectId = :projectId")
    suspend fun getPipeRuns(projectId: Long): List<PipeRunEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPipeRuns(runs: List<PipeRunEntity>)

    @Query("DELETE FROM pipe_runs WHERE projectId = :projectId")
    suspend fun clearPipeRuns(projectId: Long)

    // ---- Material settings ----
    @Query("SELECT * FROM material_settings WHERE projectId = :projectId")
    suspend fun getMaterialSettings(projectId: Long): MaterialSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMaterialSettings(settings: MaterialSettingsEntity)
}
