package com.salar.app.drawing

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.salar.app.model.*
import com.salar.app.utils.DisplayUnit
import com.salar.app.utils.UnitConverter
import kotlin.math.max
import kotlin.math.min

class DrawingView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    // ---------------- Public configuration ----------------
    var mode: CanvasMode = CanvasMode.STRUCTURE
        set(value) { field = value; selectedId = null; wireInProgress = null; invalidate() }

    var structureTool: DrawingTool = DrawingTool.WALL
        set(value) { field = value; cancelInProgress(); invalidate() }
    var electricalTool: ElectricalTool = ElectricalTool.LIGHT
        set(value) { field = value; cancelInProgress(); invalidate() }
    var plumbingTool: PlumbingTool = PlumbingTool.WATER_PIPE
        set(value) { field = value; cancelInProgress(); invalidate() }

    var displayUnit: DisplayUnit = DisplayUnit.M
    var defaultWallThicknessMM: Float = 200f
    var listener: DrawingViewListener? = null

    // ---------------- Model / history ----------------
    private var model = DrawingModel()
    private lateinit var history: UndoRedoManager
    private var historyReady = false

    fun setModel(newModel: DrawingModel) {
        model = newModel
        history = UndoRedoManager(model.deepCopy())
        historyReady = true
        recomputeRooms()
        invalidate()
    }

    fun getModel(): DrawingModel = model

    fun setActiveFloor(floor: Int) {
        model.activeFloor = floor
        selectedId = null
        invalidate()
    }

    fun setFloorCount(count: Int) {
        model.floorCount = max(1, count)
        invalidate()
    }

    // ---------------- View transform (mm <-> px) ----------------
    private var scale = 0.15f // px per mm at default zoom
    private var offsetX = 0f
    private var offsetY = 0f
    private var initializedView = false

    private fun mmToPxX(x: Float) = x * scale + offsetX
    private fun mmToPxY(y: Float) = y * scale + offsetY
    private fun pxToMM(p: PointF) = PointMM((p.x - offsetX) / scale, (p.y - offsetY) / scale)

    // ---------------- Gesture detectors ----------------
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val prevScale = scale
            scale = (scale * detector.scaleFactor).coerceIn(0.02f, 2.0f)
            // keep the focus point stable while zooming
            offsetX = detector.focusX - (detector.focusX - offsetX) * (scale / prevScale)
            offsetY = detector.focusY - (detector.focusY - offsetY) * (scale / prevScale)
            invalidate()
            return true
        }
    })

    private var lastPanX = 0f
    private var lastPanY = 0f
    private var isTwoFingerPan = false

    // wall/dimension drag state
    private var dragStartMM: PointMM? = null
    private var dragCurrentMM: PointMM? = null
    private var draggingExistingId: String? = null
    private var draggingHandle: Int = -1 // 0 = start, 1 = end, -1 = whole element

    private var selectedId: String? = null
    private var wireInProgress: MutableList<PointMM>? = null

    private val manualDimensions = mutableListOf<Pair<PointMM, PointMM>>()
    private var dimensionFirstPoint: PointMM? = null

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (wireInProgress != null && wireInProgress!!.size >= 2) {
                commitWireOrPipe()
                return true
            }
            return false
        }
    })

    // ---------------- Paints ----------------
    private val gridPaint = Paint().apply { color = Color.parseColor("#EAEAEA"); strokeWidth = 1f }
    private val wallPaint = Paint().apply { color = Color.parseColor("#1A1A1A"); style = Paint.Style.FILL; isAntiAlias = true }
    private val wallSelectedPaint = Paint().apply { color = Color.parseColor("#C62828"); style = Paint.Style.FILL; isAntiAlias = true }
    private val doorPaint = Paint().apply { color = Color.parseColor("#C62828"); style = Paint.Style.STROKE; strokeWidth = 4f; isAntiAlias = true }
    private val windowPaint = Paint().apply { color = Color.parseColor("#1565C0"); style = Paint.Style.STROKE; strokeWidth = 6f; isAntiAlias = true }
    private val roomFillPaint = Paint().apply { color = Color.parseColor("#15C62828"); style = Paint.Style.FILL }
    private val roomTextPaint = Paint().apply { color = Color.parseColor("#1A1A1A"); textSize = 30f; isAntiAlias = true; textAlign = Paint.Align.CENTER }
    private val dimensionPaint = Paint().apply { color = Color.parseColor("#616161"); strokeWidth = 2f; isAntiAlias = true }
    private val dimensionTextPaint = Paint().apply { color = Color.parseColor("#424242"); textSize = 24f; isAntiAlias = true; textAlign = Paint.Align.CENTER }
    private val previewPaint = Paint().apply { color = Color.parseColor("#80C62828"); strokeWidth = 8f; isAntiAlias = true }
    private val handlePaint = Paint().apply { color = Color.parseColor("#C62828"); style = Paint.Style.FILL; isAntiAlias = true }

    private val electricalPaint = Paint().apply { color = Color.parseColor("#F9A825"); style = Paint.Style.STROKE; strokeWidth = 4f; isAntiAlias = true }
    private val wirePaint = Paint().apply {
        color = Color.parseColor("#F9A825"); strokeWidth = 4f; style = Paint.Style.STROKE; isAntiAlias = true
        pathEffect = DashPathEffect(floatArrayOf(18f, 10f), 0f)
    }
    private val plumbingWaterPaint = Paint().apply {
        color = Color.parseColor("#1565C0"); strokeWidth = 6f; style = Paint.Style.STROKE; isAntiAlias = true
        pathEffect = DashPathEffect(floatArrayOf(2f, 0f), 0f)
    }
    private val plumbingDrainPaint = Paint().apply {
        color = Color.parseColor("#2E7D32"); strokeWidth = 6f; style = Paint.Style.STROKE; isAntiAlias = true
        pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }
    private val fixturePaint = Paint().apply { color = Color.parseColor("#1565C0"); style = Paint.Style.STROKE; strokeWidth = 4f; isAntiAlias = true }
    private val referenceWallPaint = Paint().apply { color = Color.parseColor("#B0B0B0"); style = Paint.Style.FILL; isAntiAlias = true }

    init {
        setModel(DrawingModel())
    }

    // ---------------- Drawing ----------------
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.WHITE)

        if (!initializedView && width > 0) {
            offsetX = width / 2f
            offsetY = height / 3f
            initializedView = true
        }

        drawGrid(canvas)

        val floorWalls = model.wallsOnFloor()

        if (mode != CanvasMode.STRUCTURE) {
            // show structure as light reference so MEP can be drawn "over the plan"
            for (wall in floorWalls) drawWall(canvas, wall, referenceWallPaint)
        }

        if (mode == CanvasMode.STRUCTURE) {
            for (room in model.rooms.filter { it.floorIndex == model.activeFloor }) drawRoom(canvas, room)
            for (wall in floorWalls) drawWall(canvas, wall, if (wall.id == selectedId) wallSelectedPaint else wallPaint)
            for (wall in floorWalls) {
                for (opening in model.openingsForWall(wall.id)) drawOpening(canvas, wall, opening)
                drawWallDimension(canvas, wall)
            }
            for ((a, b) in manualDimensions) drawManualDimension(canvas, a, b)
            drawSelectionHandles(canvas)
        }

        if (mode == CanvasMode.ELECTRICAL) {
            for (run in model.wireRuns.filter { it.floorIndex == model.activeFloor }) drawPolyline(canvas, run.points, wirePaint)
            for (item in model.electricalItems.filter { it.floorIndex == model.activeFloor }) drawElectricalSymbol(canvas, item)
            wireInProgress?.let { drawPolyline(canvas, it, wirePaint) }
        }

        if (mode == CanvasMode.PLUMBING) {
            for (run in model.pipeRuns.filter { it.floorIndex == model.activeFloor }) {
                drawPolyline(canvas, run.points, if (run.type == PlumbingType.DRAIN_PIPE) plumbingDrainPaint else plumbingWaterPaint)
            }
            for (fx in model.plumbingFixtures.filter { it.floorIndex == model.activeFloor }) drawPlumbingSymbol(canvas, fx)
            wireInProgress?.let { drawPolyline(canvas, it, plumbingWaterPaint) }
        }

        // live preview while dragging a new wall / dimension
        dragStartMM?.let { s ->
            dragCurrentMM?.let { e ->
                if (mode == CanvasMode.STRUCTURE && structureTool == DrawingTool.WALL && draggingExistingId == null) {
                    canvas.drawLine(mmToPxX(s.x), mmToPxY(s.y), mmToPxX(e.x), mmToPxY(e.y), previewPaint)
                    drawLengthLabel(canvas, s, e)
                }
            }
        }
    }

    private fun drawGrid(canvas: Canvas) {
        val stepMM = 500f
        val stepPx = stepMM * scale
        if (stepPx < 8) return
        var x = offsetX % stepPx
        while (x < width) { canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint); x += stepPx }
        var y = offsetY % stepPx
        while (y < height) { canvas.drawLine(0f, y, width.toFloat(), y, gridPaint); y += stepPx }
    }

    private fun drawWall(canvas: Canvas, wall: Wall, paint: Paint) {
        val p1 = PointF(mmToPxX(wall.start.x), mmToPxY(wall.start.y))
        val p2 = PointF(mmToPxX(wall.end.x), mmToPxY(wall.end.y))
        val dx = p2.x - p1.x
        val dy = p2.y - p1.y
        val len = kotlin.math.sqrt(dx * dx + dy * dy)
        if (len < 0.01f) return
        val nx = -dy / len
        val ny = dx / len
        val halfThickPx = (wall.thicknessMM * scale) / 2f

        val path = Path()
        path.moveTo(p1.x + nx * halfThickPx, p1.y + ny * halfThickPx)
        path.lineTo(p2.x + nx * halfThickPx, p2.y + ny * halfThickPx)
        path.lineTo(p2.x - nx * halfThickPx, p2.y - ny * halfThickPx)
        path.lineTo(p1.x - nx * halfThickPx, p1.y - ny * halfThickPx)
        path.close()
        canvas.drawPath(path, paint)
    }

    private fun drawOpening(canvas: Canvas, wall: Wall, opening: Opening) {
        val t = opening.offsetMM / wall.lengthMM().coerceAtLeast(1f)
        val cx = wall.start.x + (wall.end.x - wall.start.x) * t
        val cy = wall.start.y + (wall.end.y - wall.start.y) * t
        val dirX = (wall.end.x - wall.start.x) / wall.lengthMM().coerceAtLeast(1f)
        val dirY = (wall.end.y - wall.start.y) / wall.lengthMM().coerceAtLeast(1f)
        val halfW = opening.widthMM / 2f
        val a = PointMM(cx - dirX * halfW, cy - dirY * halfW)
        val b = PointMM(cx + dirX * halfW, cy + dirY * halfW)

        if (opening.isDoor) {
            canvas.drawLine(mmToPxX(a.x), mmToPxY(a.y), mmToPxX(b.x), mmToPxY(b.y), Paint().apply { color = Color.WHITE; strokeWidth = wall.thicknessMM * scale })
            // simple door swing arc
            val radiusPx = opening.widthMM * scale
            val rectF = RectF(mmToPxX(a.x) - radiusPx, mmToPxY(a.y) - radiusPx, mmToPxX(a.x) + radiusPx, mmToPxY(a.y) + radiusPx)
            canvas.drawLine(mmToPxX(a.x), mmToPxY(a.y), mmToPxX(b.x), mmToPxY(b.y), doorPaint)
            canvas.drawArc(rectF, 0f, 90f, false, doorPaint)
        } else {
            canvas.drawLine(mmToPxX(a.x), mmToPxY(a.y), mmToPxX(b.x), mmToPxY(b.y), Paint().apply { color = Color.WHITE; strokeWidth = wall.thicknessMM * scale })
            canvas.drawLine(mmToPxX(a.x), mmToPxY(a.y), mmToPxX(b.x), mmToPxY(b.y), windowPaint)
        }
    }

    private fun drawRoom(canvas: Canvas, room: RoomFace) {
        if (room.polygon.size < 3) return
        val path = Path()
        path.moveTo(mmToPxX(room.polygon[0].x), mmToPxY(room.polygon[0].y))
        for (i in 1 until room.polygon.size) path.lineTo(mmToPxX(room.polygon[i].x), mmToPxY(room.polygon[i].y))
        path.close()
        canvas.drawPath(path, roomFillPaint)

        val cx = room.polygon.map { it.x }.average().toFloat()
        val cy = room.polygon.map { it.y }.average().toFloat()
        val label = if (room.name.isNotBlank()) "${room.name}\n" else ""
        canvas.drawText(label + String.format("%.2f m²", room.areaM2()), mmToPxX(cx), mmToPxY(cy), roomTextPaint)
    }

    private fun drawWallDimension(canvas: Canvas, wall: Wall) {
        drawLengthLabel(canvas, wall.start, wall.end)
    }

    private fun drawManualDimension(canvas: Canvas, a: PointMM, b: PointMM) {
        canvas.drawLine(mmToPxX(a.x), mmToPxY(a.y), mmToPxX(b.x), mmToPxY(b.y), dimensionPaint)
        drawLengthLabel(canvas, a, b)
    }

    private fun drawLengthLabel(canvas: Canvas, a: PointMM, b: PointMM) {
        val lenMM = a.distanceTo(b)
        val midX = mmToPxX((a.x + b.x) / 2f)
        val midY = mmToPxY((a.y + b.y) / 2f)
        canvas.drawText(UnitConverter.formatMM(lenMM, displayUnit), midX, midY - 12f, dimensionTextPaint)
    }

    private fun drawSelectionHandles(canvas: Canvas) {
        val id = selectedId ?: return
        val wall = model.walls.find { it.id == id } ?: return
        canvas.drawCircle(mmToPxX(wall.start.x), mmToPxY(wall.start.y), 16f, handlePaint)
        canvas.drawCircle(mmToPxX(wall.end.x), mmToPxY(wall.end.y), 16f, handlePaint)
    }

    private fun drawPolyline(canvas: Canvas, points: List<PointMM>, paint: Paint) {
        if (points.size < 2) return
        val path = Path()
        path.moveTo(mmToPxX(points[0].x), mmToPxY(points[0].y))
        for (i in 1 until points.size) path.lineTo(mmToPxX(points[i].x), mmToPxY(points[i].y))
        canvas.drawPath(path, paint)
    }

    private fun drawElectricalSymbol(canvas: Canvas, item: ElectricalItem) {
        val x = mmToPxX(item.point.x)
        val y = mmToPxY(item.point.y)
        when (item.type) {
            ElectricalType.LIGHT -> canvas.drawCircle(x, y, 18f, electricalPaint)
            ElectricalType.SWITCH -> canvas.drawRect(x - 14f, y - 14f, x + 14f, y + 14f, electricalPaint)
            ElectricalType.SOCKET -> {
                canvas.drawCircle(x, y, 14f, electricalPaint)
                canvas.drawLine(x - 20f, y, x + 20f, y, electricalPaint)
            }
            ElectricalType.PANEL -> canvas.drawRect(x - 22f, y - 30f, x + 22f, y + 30f, electricalPaint)
            ElectricalType.WIRE -> {}
        }
    }

    private fun drawPlumbingSymbol(canvas: Canvas, fx: PlumbingFixture) {
        val x = mmToPxX(fx.point.x)
        val y = mmToPxY(fx.point.y)
        when (fx.type) {
            PlumbingType.TOILET -> canvas.drawOval(RectF(x - 16f, y - 22f, x + 16f, y + 22f), fixturePaint)
            PlumbingType.SINK -> canvas.drawRoundRect(RectF(x - 22f, y - 14f, x + 22f, y + 14f), 6f, 6f, fixturePaint)
            PlumbingType.SHOWER -> canvas.drawRect(x - 20f, y - 20f, x + 20f, y + 20f, fixturePaint)
            PlumbingType.TAP -> canvas.drawCircle(x, y, 10f, fixturePaint)
            PlumbingType.WATER_POINT -> canvas.drawCircle(x, y, 12f, fixturePaint)
            else -> {}
        }
    }

    // ---------------- Touch handling ----------------
    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)

        if (event.pointerCount >= 2) {
            handleTwoFingerPan(event)
            return true
        } else {
            isTwoFingerPan = false
        }

        if (scaleDetector.isInProgress) return true

        val screenPoint = PointF(event.x, event.y)
        val rawMM = pxToMM(screenPoint)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> handleDown(rawMM)
            MotionEvent.ACTION_MOVE -> handleMove(rawMM)
            MotionEvent.ACTION_UP -> handleUp(rawMM)
        }
        return true
    }

    private fun handleTwoFingerPan(event: MotionEvent) {
        val fx = (event.getX(0) + event.getX(1)) / 2f
        val fy = (event.getY(0) + event.getY(1)) / 2f
        if (!isTwoFingerPan) {
            isTwoFingerPan = true
            lastPanX = fx
            lastPanY = fy
        } else {
            offsetX += fx - lastPanX
            offsetY += fy - lastPanY
            lastPanX = fx
            lastPanY = fy
            invalidate()
        }
    }

    private fun handleDown(rawMM: PointMM) {
        when (mode) {
            CanvasMode.STRUCTURE -> handleStructureDown(rawMM)
            CanvasMode.ELECTRICAL -> handleElectricalDown(rawMM)
            CanvasMode.PLUMBING -> handlePlumbingDown(rawMM)
        }
    }

    private fun handleMove(rawMM: PointMM) {
        when (mode) {
            CanvasMode.STRUCTURE -> handleStructureMove(rawMM)
            else -> {
                // panning empty canvas with one finger while placing MEP items is disabled;
                // use two fingers to pan in these modes to avoid accidental drags.
            }
        }
    }

    private fun handleUp(rawMM: PointMM) {
        when (mode) {
            CanvasMode.STRUCTURE -> handleStructureUp(rawMM)
            else -> {}
        }
    }

    // ---- Structure mode ----
    private fun handleStructureDown(rawMM: PointMM) {
        val snapped = Geometry.snapPoint(rawMM, model.wallsOnFloor())
        when (structureTool) {
            DrawingTool.WALL -> {
                dragStartMM = snapped
                dragCurrentMM = snapped
            }
            DrawingTool.SELECT, DrawingTool.MOVE -> {
                val hit = hitTestWallHandle(rawMM)
                if (hit != null) {
                    draggingExistingId = hit.first
                    draggingHandle = hit.second
                    selectedId = hit.first
                } else {
                    val wall = hitTestWall(rawMM)
                    selectedId = wall?.id
                    draggingExistingId = wall?.id
                    draggingHandle = -1
                    dragStartMM = rawMM
                }
                reportSelection()
            }
            DrawingTool.DOOR, DrawingTool.WINDOW -> {
                placeOpening(rawMM, structureTool == DrawingTool.DOOR)
            }
            DrawingTool.DIMENSION -> {
                val p = Geometry.snapPoint(rawMM, model.wallsOnFloor())
                val first = dimensionFirstPoint
                if (first == null) {
                    dimensionFirstPoint = p
                } else {
                    manualDimensions.add(first to p)
                    dimensionFirstPoint = null
                    invalidate()
                }
            }
            DrawingTool.DELETE -> {
                deleteNearest(rawMM)
            }
        }
        invalidate()
    }

    private fun handleStructureMove(rawMM: PointMM) {
        if (structureTool == DrawingTool.WALL && dragStartMM != null) {
            dragCurrentMM = Geometry.snapAngle(dragStartMM!!, Geometry.snapPoint(rawMM, model.wallsOnFloor()))
            invalidate()
            return
        }
        if ((structureTool == DrawingTool.SELECT || structureTool == DrawingTool.MOVE) && draggingExistingId != null) {
            val wall = model.walls.find { it.id == draggingExistingId } ?: return
            val snapped = Geometry.snapPoint(rawMM, model.wallsOnFloor().filter { it.id != wall.id })
            when (draggingHandle) {
                0 -> wall.start = snapped
                1 -> wall.end = snapped
                else -> {
                    val start = dragStartMM
                    if (start != null) {
                        val dx = rawMM.x - start.x
                        val dy = rawMM.y - start.y
                        wall.start = PointMM(wall.start.x + dx, wall.start.y + dy)
                        wall.end = PointMM(wall.end.x + dx, wall.end.y + dy)
                        dragStartMM = rawMM
                    }
                }
            }
            invalidate()
        }
    }

    private fun handleStructureUp(rawMM: PointMM) {
        if (structureTool == DrawingTool.WALL && dragStartMM != null) {
            val start = dragStartMM!!
            val end = dragCurrentMM ?: rawMM
            if (start.distanceTo(end) > 50f) { // ignore accidental taps under 5cm
                val wall = Wall(start = start, end = end, thicknessMM = defaultWallThicknessMM, floorIndex = model.activeFloor)
                model.walls.add(wall)
                commitHistory()
                recomputeRooms()
                listener?.onWallDrawn(wall.id, wall.lengthMM())
            }
            dragStartMM = null
            dragCurrentMM = null
        }
        if ((structureTool == DrawingTool.SELECT || structureTool == DrawingTool.MOVE) && draggingExistingId != null) {
            commitHistory()
            recomputeRooms()
            draggingExistingId = null
            draggingHandle = -1
            dragStartMM = null
        }
        invalidate()
    }

    /** Adjust the currently selected wall to an exact length, keeping its start point and direction. */
    fun setSelectedWallExactLength(lengthMM: Float) {
        val wall = model.walls.find { it.id == selectedId } ?: return
        val dx = wall.end.x - wall.start.x
        val dy = wall.end.y - wall.start.y
        val curLen = wall.lengthMM().coerceAtLeast(0.01f)
        val ux = dx / curLen
        val uy = dy / curLen
        wall.end = PointMM(wall.start.x + ux * lengthMM, wall.start.y + uy * lengthMM)
        commitHistory()
        recomputeRooms()
        invalidate()
    }

    fun setSelectedWallThickness(thicknessMM: Float) {
        val wall = model.walls.find { it.id == selectedId } ?: return
        wall.thicknessMM = thicknessMM
        commitHistory()
        invalidate()
    }

    fun setSelectedWallId(id: String?) { selectedId = id; invalidate() }
    fun getSelectedWallId(): String? = selectedId

    fun setWallByWallId(id: String) = model.walls.find { it.id == id }

    private fun placeOpening(rawMM: PointMM, isDoor: Boolean) {
        val wall = hitTestWall(rawMM) ?: return
        val proj = projectOntoWall(rawMM, wall)
        val offset = wall.start.distanceTo(proj)
        val defaultWidth = if (isDoor) 900f else 1200f
        val clampedOffset = offset.coerceIn(defaultWidth / 2f, (wall.lengthMM() - defaultWidth / 2f).coerceAtLeast(defaultWidth / 2f))
        model.openings.add(Opening(wallId = wall.id, offsetMM = clampedOffset, widthMM = defaultWidth, isDoor = isDoor))
        commitHistory()
    }

    private fun projectOntoWall(p: PointMM, wall: Wall): PointMM {
        val abx = wall.end.x - wall.start.x
        val aby = wall.end.y - wall.start.y
        val lenSq = abx * abx + aby * aby
        if (lenSq < 1e-6) return wall.start
        var t = ((p.x - wall.start.x) * abx + (p.y - wall.start.y) * aby) / lenSq
        t = t.coerceIn(0f, 1f)
        return PointMM(wall.start.x + t * abx, wall.start.y + t * aby)
    }

    private fun hitTestWall(p: PointMM, toleranceMM: Float = 250f): Wall? {
        var best: Wall? = null
        var bestDist = toleranceMM
        for (wall in model.wallsOnFloor()) {
            val proj = projectOntoWall(p, wall)
            val d = p.distanceTo(proj)
            if (d < bestDist) { bestDist = d; best = wall }
        }
        return best
    }

    private fun hitTestWallHandle(p: PointMM, toleranceMM: Float = 300f): Pair<String, Int>? {
        for (wall in model.wallsOnFloor()) {
            if (p.distanceTo(wall.start) < toleranceMM) return wall.id to 0
            if (p.distanceTo(wall.end) < toleranceMM) return wall.id to 1
        }
        return null
    }

    private fun deleteNearest(p: PointMM) {
        val wall = hitTestWall(p)
        if (wall != null) {
            model.walls.remove(wall)
            model.openings.removeAll { it.wallId == wall.id }
            commitHistory()
            recomputeRooms()
            return
        }
    }

    // ---- Electrical mode ----
    private fun handleElectricalDown(rawMM: PointMM) {
        when (electricalTool) {
            ElectricalTool.LIGHT -> addElectrical(ElectricalType.LIGHT, rawMM)
            ElectricalTool.SWITCH -> addElectrical(ElectricalType.SWITCH, rawMM)
            ElectricalTool.SOCKET -> addElectrical(ElectricalType.SOCKET, rawMM)
            ElectricalTool.PANEL -> addElectrical(ElectricalType.PANEL, rawMM)
            ElectricalTool.WIRE -> appendToRunInProgress(rawMM)
            ElectricalTool.SELECT -> selectNearestElectrical(rawMM)
            ElectricalTool.DELETE -> deleteNearestElectrical(rawMM)
        }
    }

    private fun addElectrical(type: ElectricalType, p: PointMM) {
        model.electricalItems.add(ElectricalItem(type = type, point = p, floorIndex = model.activeFloor))
        commitHistory()
        invalidate()
    }

    private fun selectNearestElectrical(p: PointMM) {
        val item = model.electricalItems.filter { it.floorIndex == model.activeFloor }
            .minByOrNull { it.point.distanceTo(p) }
        selectedId = item?.id
        reportSelection()
        invalidate()
    }

    private fun deleteNearestElectrical(p: PointMM) {
        val item = model.electricalItems.filter { it.floorIndex == model.activeFloor }
            .minByOrNull { it.point.distanceTo(p) }
        if (item != null && item.point.distanceTo(p) < 400f) {
            model.electricalItems.remove(item)
            commitHistory(); invalidate(); return
        }
        val run = model.wireRuns.filter { it.floorIndex == model.activeFloor }
            .minByOrNull { r -> r.points.minOf { it.distanceTo(p) } }
        if (run != null) { model.wireRuns.remove(run); commitHistory(); invalidate() }
    }

    // ---- Plumbing mode ----
    private fun handlePlumbingDown(rawMM: PointMM) {
        when (plumbingTool) {
            PlumbingTool.WATER_PIPE -> appendToPipeInProgress(rawMM, PlumbingType.WATER_PIPE)
            PlumbingTool.DRAIN_PIPE -> appendToPipeInProgress(rawMM, PlumbingType.DRAIN_PIPE)
            PlumbingTool.TOILET -> addFixture(PlumbingType.TOILET, rawMM)
            PlumbingTool.SINK -> addFixture(PlumbingType.SINK, rawMM)
            PlumbingTool.SHOWER -> addFixture(PlumbingType.SHOWER, rawMM)
            PlumbingTool.TAP -> addFixture(PlumbingType.TAP, rawMM)
            PlumbingTool.SELECT -> {}
            PlumbingTool.DELETE -> deleteNearestPlumbing(rawMM)
        }
    }

    private fun addFixture(type: PlumbingType, p: PointMM) {
        model.plumbingFixtures.add(PlumbingFixture(type = type, point = p, floorIndex = model.activeFloor))
        commitHistory()
        invalidate()
    }

    private var pipeTypeInProgress: PlumbingType = PlumbingType.WATER_PIPE

    private fun appendToPipeInProgress(p: PointMM, type: PlumbingType) {
        if (wireInProgress == null || pipeTypeInProgress != type) {
            wireInProgress = mutableListOf(p)
            pipeTypeInProgress = type
        } else {
            wireInProgress!!.add(p)
        }
        invalidate()
    }

    private fun appendToRunInProgress(p: PointMM) {
        if (wireInProgress == null) wireInProgress = mutableListOf(p)
        else wireInProgress!!.add(p)
        invalidate()
    }

    private fun commitWireOrPipe() {
        val pts = wireInProgress ?: return
        if (pts.size >= 2) {
            if (mode == CanvasMode.ELECTRICAL) {
                model.wireRuns.add(WireRun(points = pts.toMutableList(), floorIndex = model.activeFloor))
            } else if (mode == CanvasMode.PLUMBING) {
                model.pipeRuns.add(PipeRun(type = pipeTypeInProgress, points = pts.toMutableList(), floorIndex = model.activeFloor))
            }
            commitHistory()
        }
        wireInProgress = null
        invalidate()
    }

    private fun deleteNearestPlumbing(p: PointMM) {
        val fx = model.plumbingFixtures.filter { it.floorIndex == model.activeFloor }.minByOrNull { it.point.distanceTo(p) }
        if (fx != null && fx.point.distanceTo(p) < 400f) { model.plumbingFixtures.remove(fx); commitHistory(); invalidate(); return }
        val run = model.pipeRuns.filter { it.floorIndex == model.activeFloor }.minByOrNull { r -> r.points.minOf { it.distanceTo(p) } }
        if (run != null) { model.pipeRuns.remove(run); commitHistory(); invalidate() }
    }

    // ---------------- History / rooms ----------------
    private fun commitHistory() {
        if (!historyReady) return
        history.push(model.deepCopy())
        listener?.onHistoryChanged(history.canUndo(), history.canRedo())
        listener?.onModelChanged()
    }

    fun undo() {
        model = history.undo()
        listener?.onHistoryChanged(history.canUndo(), history.canRedo())
        listener?.onModelChanged()
        invalidate()
    }

    fun redo() {
        model = history.redo()
        listener?.onHistoryChanged(history.canUndo(), history.canRedo())
        listener?.onModelChanged()
        invalidate()
    }

    fun canUndo() = historyReady && history.canUndo()
    fun canRedo() = historyReady && history.canRedo()

    private fun recomputeRooms() {
        val detected = Geometry.detectRooms(model.wallsOnFloor(), model.activeFloor)
        // preserve names of rooms that still match roughly the same polygon centroid
        val old = model.rooms.filter { it.floorIndex == model.activeFloor }
        val updated = detected.map { newRoom ->
            val cx = newRoom.polygon.map { it.x }.average()
            val cy = newRoom.polygon.map { it.y }.average()
            val match = old.minByOrNull { o ->
                val ocx = o.polygon.map { it.x }.average()
                val ocy = o.polygon.map { it.y }.average()
                kotlin.math.hypot(ocx - cx, ocy - cy)
            }
            if (match != null && kotlin.math.hypot(
                    match.polygon.map { it.x }.average() - cx,
                    match.polygon.map { it.y }.average() - cy
                ) < 300.0
            ) newRoom.copy(id = match.id, name = match.name) else newRoom
        }
        model.rooms.removeAll { it.floorIndex == model.activeFloor }
        model.rooms.addAll(updated)
    }

    fun renameRoomAt(id: String, name: String) {
        model.rooms.find { it.id == id }?.name = name
        invalidate()
    }

    fun getRooms(): List<RoomFace> = model.rooms.filter { it.floorIndex == model.activeFloor }

    private fun reportSelection() {
        val id = selectedId
        if (id == null) { listener?.onSelectionInfo(null); return }
        val wall = model.walls.find { it.id == id }
        if (wall != null) {
            listener?.onSelectionInfo(UnitConverter.formatMM(wall.lengthMM(), displayUnit))
            return
        }
        listener?.onSelectionInfo(null)
    }

    private fun cancelInProgress() {
        dragStartMM = null
        dragCurrentMM = null
        draggingExistingId = null
        wireInProgress = null
        dimensionFirstPoint = null
    }

    fun zoomIn() { scale = (scale * 1.25f).coerceAtMost(2.0f); invalidate() }
    fun zoomOut() { scale = (scale * 0.8f).coerceAtLeast(0.02f); invalidate() }
}
