package com.salar.app.model

import java.util.UUID

/**
 * All coordinates in this file are stored in MILLIMETERS (real-world units),
 * never in screen pixels. The drawing view is responsible for converting
 * between mm <-> screen px using its current zoom/pan state. This keeps the
 * model unit-independent so mm/cm/m display is just a formatting choice.
 */

data class PointMM(val x: Float, val y: Float) {
    fun distanceTo(o: PointMM): Float {
        val dx = x - o.x
        val dy = y - o.y
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }
}

enum class LayerType { STRUCTURE, ELECTRICAL, PLUMBING, DIMENSION }

enum class ElectricalType { LIGHT, SWITCH, SOCKET, PANEL, WIRE }
enum class PlumbingType { WATER_PIPE, DRAIN_PIPE, TOILET, SINK, SHOWER, TAP, WATER_POINT }

data class Wall(
    val id: String = UUID.randomUUID().toString(),
    var start: PointMM,
    var end: PointMM,
    var thicknessMM: Float = 200f,
    var floorIndex: Int = 0
) {
    fun lengthMM(): Float = start.distanceTo(end)
}

/** An opening sits on a wall at [offsetMM] measured from wall.start, with a given [widthMM]. */
data class Opening(
    val id: String = UUID.randomUUID().toString(),
    val wallId: String,
    var offsetMM: Float,
    var widthMM: Float,
    var isDoor: Boolean,
    var heightMM: Float = if (isDoor) 2100f else 1200f,
    var sillHeightMM: Float = if (isDoor) 0f else 900f
)

/** Automatically detected (or user-confirmed) closed room polygon. */
data class RoomFace(
    val id: String = UUID.randomUUID().toString(),
    var name: String = "",
    val polygon: List<PointMM>,
    var floorIndex: Int = 0
) {
    /** Shoelace formula, returns area in square meters. */
    fun areaM2(): Double {
        var sum = 0.0
        val n = polygon.size
        for (i in 0 until n) {
            val p1 = polygon[i]
            val p2 = polygon[(i + 1) % n]
            sum += (p1.x.toDouble() * p2.y.toDouble()) - (p2.x.toDouble() * p1.y.toDouble())
        }
        val areaMM2 = kotlin.math.abs(sum) / 2.0
        return areaMM2 / 1_000_000.0 // mm^2 -> m^2
    }

    fun perimeterM(): Double {
        var sum = 0.0
        val n = polygon.size
        for (i in 0 until n) {
            sum += polygon[i].distanceTo(polygon[(i + 1) % n])
        }
        return sum / 1000.0
    }
}

data class ElectricalItem(
    val id: String = UUID.randomUUID().toString(),
    var type: ElectricalType,
    var point: PointMM,
    var floorIndex: Int = 0
)

data class WireRun(
    val id: String = UUID.randomUUID().toString(),
    var points: MutableList<PointMM>,
    var floorIndex: Int = 0
) {
    fun lengthMM(): Float {
        var total = 0f
        for (i in 0 until points.size - 1) total += points[i].distanceTo(points[i + 1])
        return total
    }
}

data class PlumbingFixture(
    val id: String = UUID.randomUUID().toString(),
    var type: PlumbingType,
    var point: PointMM,
    var floorIndex: Int = 0
)

data class PipeRun(
    val id: String = UUID.randomUUID().toString(),
    var type: PlumbingType, // WATER_PIPE or DRAIN_PIPE
    var diameterMM: Float = 20f,
    var points: MutableList<PointMM>,
    var floorIndex: Int = 0
) {
    fun lengthMM(): Float {
        var total = 0f
        for (i in 0 until points.size - 1) total += points[i].distanceTo(points[i + 1])
        return total
    }
}

/** The full in-memory state of a single project's drawing, all floors combined. */
class DrawingModel {
    val walls = mutableListOf<Wall>()
    val openings = mutableListOf<Opening>()
    val rooms = mutableListOf<RoomFace>()
    val electricalItems = mutableListOf<ElectricalItem>()
    val wireRuns = mutableListOf<WireRun>()
    val plumbingFixtures = mutableListOf<PlumbingFixture>()
    val pipeRuns = mutableListOf<PipeRun>()
    var activeFloor: Int = 0
    var floorCount: Int = 1

    fun wallsOnFloor(floor: Int = activeFloor) = walls.filter { it.floorIndex == floor }
    fun openingsForWall(wallId: String) = openings.filter { it.wallId == wallId }

    fun deepCopy(): DrawingModel {
        val copy = DrawingModel()
        copy.walls.addAll(walls.map { it.copy() })
        copy.openings.addAll(openings.map { it.copy() })
        copy.rooms.addAll(rooms.map { it.copy(polygon = it.polygon.toList()) })
        copy.electricalItems.addAll(electricalItems.map { it.copy() })
        copy.wireRuns.addAll(wireRuns.map { it.copy(points = it.points.toMutableList()) })
        copy.plumbingFixtures.addAll(plumbingFixtures.map { it.copy() })
        copy.pipeRuns.addAll(pipeRuns.map { it.copy(points = it.points.toMutableList()) })
        copy.activeFloor = activeFloor
        copy.floorCount = floorCount
        return copy
    }
}
