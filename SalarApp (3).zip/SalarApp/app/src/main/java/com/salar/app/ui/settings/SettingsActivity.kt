package com.salar.app.ui.settings

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.salar.app.R
import com.salar.app.databinding.ActivitySettingsBinding
import com.salar.app.utils.DisplayUnit
import com.salar.app.utils.Prefs

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        when (Prefs.getUnit(this)) {
            "MM" -> binding.radioMM.isChecked = true
            "CM" -> binding.radioCM.isChecked = true
            else -> binding.radioM.isChecked = true
        }
        binding.editDefaultThickness.setText(Prefs.getDefaultWallThickness(this).toString())

        binding.btnSaveSettings.setOnClickListener {
            val unit = when (binding.radioUnits.checkedRadioButtonId) {
                R.id.radioMM -> DisplayUnit.MM
                R.id.radioCM -> DisplayUnit.CM
                else -> DisplayUnit.M
            }
            Prefs.setUnit(this, unit.name)
            val thickness = binding.editDefaultThickness.text.toString().toFloatOrNull() ?: 200f
            Prefs.setDefaultWallThickness(this, thickness)
            Toast.makeText(this, getString(R.string.save), Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
