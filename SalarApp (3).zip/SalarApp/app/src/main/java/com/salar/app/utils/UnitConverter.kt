package com.salar.app.utils

enum class DisplayUnit(val label: String) {
    MM("mm"), CM("cm"), M("m")
}

/** All internal storage is millimeters; this only affects what is shown to the user. */
object UnitConverter {

    fun fromMM(valueMM: Float, unit: DisplayUnit): Float = when (unit) {
        DisplayUnit.MM -> valueMM
        DisplayUnit.CM -> valueMM / 10f
        DisplayUnit.M -> valueMM / 1000f
    }

    fun toMM(value: Float, unit: DisplayUnit): Float = when (unit) {
        DisplayUnit.MM -> value
        DisplayUnit.CM -> value * 10f
        DisplayUnit.M -> value * 1000f
    }

    fun formatMM(valueMM: Float, unit: DisplayUnit): String {
        val v = fromMM(valueMM, unit)
        return when (unit) {
            DisplayUnit.MM -> "${v.toInt()} ${unit.label}"
            DisplayUnit.CM -> String.format("%.1f %s", v, unit.label)
            DisplayUnit.M -> String.format("%.2f %s", v, unit.label)
        }
    }
}
