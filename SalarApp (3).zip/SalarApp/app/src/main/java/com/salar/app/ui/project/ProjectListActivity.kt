package com.salar.app.ui.project

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.salar.app.R
import com.salar.app.data.ProjectRepository
import com.salar.app.data.entity.ProjectEntity
import com.salar.app.databinding.ActivityProjectListBinding
import com.salar.app.ui.drawing.DrawingActivity
import com.salar.app.utils.Prefs
import kotlinx.coroutines.launch

class ProjectListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProjectListBinding
    private lateinit var repository: ProjectRepository
    private lateinit var adapter: ProjectAdapter

    /** If launched from the main menu without a chosen project, we open this screen next. */
    private var targetAfterPick: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProjectListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = ProjectRepository(this)
        targetAfterPick = intent.getStringExtra("target_after_pick")

        adapter = ProjectAdapter(
            onOpen = { openProject(it) },
            onDuplicate = { duplicateProject(it) },
            onDelete = { confirmDelete(it) }
        )
        binding.recyclerProjects.layoutManager = LinearLayoutManager(this)
        binding.recyclerProjects.adapter = adapter

        binding.btnAddProject.setOnClickListener {
            startActivity(Intent(this, NewProjectActivity::class.java))
        }

        lifecycleScope.launch {
            repository.observeProjects().collect { list ->
                adapter.submitList(list)
                binding.textEmpty.visibility = if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            }
        }
    }

    private fun openProject(project: ProjectEntity) {
        Prefs.setLastProject(this, project.id)
        val targetClassName = targetAfterPick
        val intent = if (targetClassName != null) {
            Intent(this, Class.forName(targetClassName))
        } else {
            Intent(this, DrawingActivity::class.java)
        }
        intent.putExtra("project_id", project.id)
        startActivity(intent)
        finish()
    }

    private fun duplicateProject(project: ProjectEntity) {
        lifecycleScope.launch { repository.duplicateProject(project) }
    }

    private fun confirmDelete(project: ProjectEntity) {
        AlertDialog.Builder(this)
            .setMessage(R.string.confirm_delete_project)
            .setPositiveButton(R.string.yes) { _, _ ->
                lifecycleScope.launch { repository.deleteProject(project) }
            }
            .setNegativeButton(R.string.no, null)
            .show()
    }
}
