package com.salar.app.ui.plumbing

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.salar.app.R
import com.salar.app.data.ProjectRepository
import com.salar.app.databinding.ActivityPlumbingBinding
import com.salar.app.drawing.CanvasMode
import com.salar.app.drawing.DrawingViewListener
import com.salar.app.drawing.PlumbingTool
import com.salar.app.utils.DisplayUnit
import com.salar.app.utils.Prefs
import com.salar.app.utils.UnitConverter
import kotlinx.coroutines.launch

/** Plumbing overlay: water/drain pipe runs + fixtures drawn on top of the floor plan. */
class PlumbingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlumbingBinding
    private lateinit var repository: ProjectRepository
    private var projectId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlumbingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = ProjectRepository(this)

        projectId = intent.getLongExtra("project_id", Prefs.getLastProject(this))
        if (projectId == -1L) { finish(); return }

        binding.drawingViewPlumb.mode = CanvasMode.PLUMBING
        binding.drawingViewPlumb.displayUnit = DisplayUnit.valueOf(Prefs.getUnit(this))
        binding.drawingViewPlumb.listener = object : DrawingViewListener {
            override fun onModelChanged() { updateSummary() }
        }

        binding.toolWaterPipe.setOnClickListener { select(PlumbingTool.WATER_PIPE) }
        binding.toolDrainPipe.setOnClickListener { select(PlumbingTool.DRAIN_PIPE) }
        binding.toolToilet.setOnClickListener { select(PlumbingTool.TOILET) }
        binding.toolSink.setOnClickListener { select(PlumbingTool.SINK) }
        binding.toolShower.setOnClickListener { select(PlumbingTool.SHOWER) }
        binding.toolTap.setOnClickListener { select(PlumbingTool.TAP) }
        binding.toolPlumbDelete.setOnClickListener { select(PlumbingTool.DELETE) }
        binding.toolFinishPipe.setOnClickListener { select(PlumbingTool.WATER_PIPE) }
        binding.toolPlumbSave.setOnClickListener { saveProject() }

        lifecycleScope.launch {
            val project = repository.getProject(projectId)
            binding.textProjectTitlePlumb.text = project?.name ?: ""
            val model = repository.loadDrawing(projectId)
            binding.drawingViewPlumb.setModel(model)
            updateSummary()
        }
    }

    private fun select(tool: PlumbingTool) {
        binding.drawingViewPlumb.plumbingTool = tool
    }

    private fun updateSummary() {
        val model = binding.drawingViewPlumb.getModel()
        val floor = model.activeFloor
        val points = model.plumbingFixtures.count { it.floorIndex == floor }
        val pipeLengthMM = model.pipeRuns.filter { it.floorIndex == floor }.sumOf { it.lengthMM().toDouble() }.toFloat()
        binding.textPlumbSummary.text = getString(
            R.string.pipe_summary, points,
            UnitConverter.formatMM(pipeLengthMM, binding.drawingViewPlumb.displayUnit)
        )
    }

    private fun saveProject() {
        lifecycleScope.launch { repository.saveDrawing(projectId, binding.drawingViewPlumb.getModel()) }
    }

    override fun onPause() {
        super.onPause()
        saveProject()
    }
}
