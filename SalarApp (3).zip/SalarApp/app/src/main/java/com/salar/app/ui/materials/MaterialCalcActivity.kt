package com.salar.app.ui.materials

import android.os.Bundle
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.salar.app.R
import com.salar.app.calculation.ConcreteInput
import com.salar.app.calculation.MaterialCalculator
import com.salar.app.data.ProjectRepository
import com.salar.app.data.entity.MaterialSettingsEntity
import com.salar.app.databinding.ActivityMaterialCalcBinding
import com.salar.app.utils.Prefs
import kotlinx.coroutines.launch

class MaterialCalcActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMaterialCalcBinding
    private lateinit var repository: ProjectRepository
    private var projectId: Long = -1L
    private var settings = MaterialSettingsEntity(projectId = -1L)

    // dynamically built rows: label -> (length, width, thickness, count)
    private val concreteRows = LinkedHashMap<String, List<EditText>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMaterialCalcBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = ProjectRepository(this)

        projectId = intent.getLongExtra("project_id", Prefs.getLastProject(this))
        if (projectId == -1L) { finish(); return }

        buildConcreteRows()
        setupTabs()

        binding.btnFromPlan.setOnClickListener { fillFromPlan() }
        binding.btnCalcWall.setOnClickListener { calculateWall() }
        binding.btnCalcConcrete.setOnClickListener { calculateConcrete() }
        binding.btnEditRatios.setOnClickListener { showRatiosDialog() }

        lifecycleScope.launch {
            settings = repository.getMaterialSettings(projectId)
        }
    }

    private fun setupTabs() {
        binding.tabWall.setOnClickListener {
            binding.sectionWall.visibility = android.view.View.VISIBLE
            binding.sectionConcrete.visibility = android.view.View.GONE
        }
        binding.tabConcrete.setOnClickListener {
            binding.sectionWall.visibility = android.view.View.GONE
            binding.sectionConcrete.visibility = android.view.View.VISIBLE
        }
    }

    private fun buildConcreteRows() {
        val labelMap = listOf(
            binding.rowFoundation to getString(R.string.foundation_label),
            binding.rowSlab to getString(R.string.slab_label),
            binding.rowColumn to getString(R.string.column_label),
            binding.rowBeam to getString(R.string.beam_label)
        )
        for ((container, label) in labelMap) {
            container.removeAllViews()
            val labelView = TextView(this).apply {
                text = label
                textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f)
                gravity = android.view.Gravity.CENTER_VERTICAL
            }
            container.addView(labelView)
            val edits = mutableListOf<EditText>()
            repeat(4) { idx ->
                val edit = EditText(this).apply {
                    inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    setText(if (idx == 3) "1" else "0")
                    textSize = 13f
                }
                edits.add(edit)
                container.addView(edit)
            }
            concreteRows[label] = edits
        }
    }

    private fun fillFromPlan() {
        lifecycleScope.launch {
            val model = repository.loadDrawing(projectId)
            val calc = MaterialCalculator(settings)
            val result = calc.fromDrawing(model)
            binding.editWallLength.setText(String.format("%.2f", model.wallsOnFloor().sumOf { it.lengthMM().toDouble() } / 1000.0))
            binding.textWallResult.text = formatWallResult(result)
        }
    }

    private fun calculateWall() {
        val lengthM = binding.editWallLength.text.toString().toDoubleOrNull() ?: 0.0
        val heightM = binding.editWallHeight.text.toString().toDoubleOrNull() ?: 3.0
        val thicknessM = binding.editWallThickness.text.toString().toDoubleOrNull() ?: 0.2
        val openingsAreaM2 = binding.editOpeningsArea.text.toString().toDoubleOrNull() ?: 0.0

        val calc = MaterialCalculator(settings)
        val result = calc.fromManualWall(lengthM, heightM, thicknessM, openingsAreaM2)
        binding.textWallResult.text = formatWallResult(result)
    }

    private fun formatWallResult(result: com.salar.app.calculation.QuantityResult): String {
        return getString(R.string.wall_length_m) + "\n" +
            String.format("• د دیوال ساحه: %.2f m²\n", result.netWallAreaM2) +
            String.format("• د دیوال حجم: %.2f m³\n", result.wallVolumeM3) +
            String.format("• د بلاک/چینو شمېر: %d", result.blockCount)
    }

    private fun calculateConcrete() {
        val inputs = concreteRows.map { (label, edits) ->
            ConcreteInput(
                label = label,
                lengthM = edits[0].text.toString().toFloatOrNull() ?: 0f,
                widthM = edits[1].text.toString().toFloatOrNull() ?: 0f,
                thicknessM = edits[2].text.toString().toFloatOrNull() ?: 0f,
                count = edits[3].text.toString().toIntOrNull() ?: 1
            )
        }
        val calc = MaterialCalculator(settings)
        val result = calc.concreteQuantities(inputs)
        binding.textConcreteResult.text =
            String.format("• د کانکریټ حجم: %.2f m³\n", result.concreteVolumeM3) +
            String.format("• سمنت: %.1f بوجۍ\n", result.cementBags) +
            String.format("• شګه: %.2f m³\n", result.sandM3) +
            String.format("• جغل: %.2f m³", result.aggregateM3)
    }

    private fun showRatiosDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_ratios, null)
        val cement = view.findViewById<EditText>(R.id.editCement)
        val sand = view.findViewById<EditText>(R.id.editSand)
        val aggregate = view.findViewById<EditText>(R.id.editAggregate)
        cement.setText(settings.cementRatio.toString())
        sand.setText(settings.sandRatio.toString())
        aggregate.setText(settings.aggregateRatio.toString())

        AlertDialog.Builder(this)
            .setTitle(R.string.edit_ratios)
            .setView(view)
            .setPositiveButton(R.string.save) { _, _ ->
                settings = settings.copy(
                    cementRatio = cement.text.toString().toFloatOrNull() ?: settings.cementRatio,
                    sandRatio = sand.text.toString().toFloatOrNull() ?: settings.sandRatio,
                    aggregateRatio = aggregate.text.toString().toFloatOrNull() ?: settings.aggregateRatio
                )
                lifecycleScope.launch { repository.saveMaterialSettings(settings) }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
