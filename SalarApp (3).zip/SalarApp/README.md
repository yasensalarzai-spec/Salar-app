# سالار (Salar) — Construction Planning & Quantity Estimation

A 100% offline Android app for drawing a 2D floor plan, viewing it in 3D,
laying out electrical and plumbing, and estimating construction material
quantities — built for construction workers and engineers on ordinary phones.

## What is actually working in this v1 (not placeholders)

- **Projects**: create / open / rename / duplicate / delete, stored in a
  local SQLite database (Room). Nothing leaves the phone — no `INTERNET`
  permission is even requested.
- **2D drawing** (`DrawingView`): draw walls by dragging, snap to corners
  and existing walls, set an *exact* wall length after drawing, change wall
  thickness, add doors/windows by tapping a wall, select/move/resize/delete
  any element, manual dimension lines, pinch-zoom, two-finger pan,
  undo/redo, multiple floors.
- **Automatic room detection**: as soon as walls form a closed loop, its
  area (m²) and perimeter are computed automatically via planar-graph face
  tracing (`Geometry.detectRooms`) — no manual outlining needed.
- **3D view** (`Simple3DView`): every wall is extruded to a box using its
  real height/thickness and rendered with a rotating, pinch-zoomable
  camera (drag to orbit). This is a lightweight custom Canvas renderer
  (no OpenGL/Filament dependency), so it stays fast on low-end phones and
  is easy to swap for a full 3D engine later.
- **Electrical mode**: place lights/switches/sockets/panel, draw wire runs
  directly over the plan, live count of each + total wire length.
- **Plumbing mode**: water/drain pipe runs, toilet/sink/shower/tap fixtures,
  live count + total pipe length.
- **Material calculator**: wall area/volume from the drawn plan *or* manual
  entry, block/brick count, and concrete → cement/sand/aggregate quantities
  for foundation/slab/column/beam — with the cement:sand:aggregate ratio,
  bag weight, dry-volume factor and block size all user-editable per
  project (`MaterialSettingsEntity`).
- **Export & share**: plan as PNG, plan as PDF, and a material quantity
  report as PDF — handed to the Android share sheet via `FileProvider`.
- **Settings**: preferred unit (mm/cm/m) and default wall thickness.
- **Auto-save**: every screen saves the drawing to the database in
  `onPause()`, plus an explicit "خوندي کول" (save) button.
- **UI**: Pashto strings, RTL layout, red/black theme, large one-hand-usable
  buttons, as specified.

## Known v1 simplifications (clearly structured to extend later)

- Manual dimension lines (the "Dimension" tool) are kept in memory for the
  current session only — not yet persisted to the database. Everything
  else (walls, openings, rooms, electrical, plumbing, materials) *is*
  persisted.
- 3D is a custom Canvas-based extrusion, not a full 3D engine — it clearly
  represents the building (walls, height, rotation) as required, but does
  not yet render door/window cutouts or textures in 3D.
- The material calculator currently assumes one wall height for the whole
  "from current plan" calculation (the 3D screen's per-wall height slider
  is a good next place to feed per-wall heights back into it).
- PDF export of the 2D plan rasterizes the on-screen view; for very large
  multi-floor plans you'd want a multi-page PDF (natural next step in
  `ExportManager`).

## Project structure

```
app/src/main/java/com/salar/app/
  data/            Room database, entities, DAOs, ProjectRepository
  model/           Plain domain models (Wall, Opening, RoomFace, ...)
  drawing/         DrawingView (2D engine), Geometry (snapping + room
                   detection), UndoRedoManager, tool enums
  threeD/          Simple3DView (custom Canvas 3D renderer)
  calculation/     MaterialCalculator (editable-ratio quantity math)
  export/          ExportManager (PNG/PDF export + Android share)
  ui/              One package per screen (project, drawing, electrical,
                   plumbing, materials, threeD, reports, settings)
  utils/           UnitConverter, Prefs (SharedPreferences)
```

Every module above is a separate class/package as required, so each part
(2D, 3D, database, materials, electrical, plumbing, export, UI) can be
worked on independently.

## How to build the APK

### Option A — Android Studio (recommended, easiest)

1. Install **Android Studio** (2023.1 "Iguana" or newer) from
   https://developer.android.com/studio
2. `File → Open`, select the `SalarApp` folder (the one containing
   `settings.gradle`).
3. Let Gradle sync (Android Studio will download the Gradle wrapper JAR
   and all dependencies automatically the first time — this needs internet
   *once*, during development only; the built app itself needs none).
4. Plug in an Android phone via USB with **Developer options → USB
   debugging** enabled (or use the built-in emulator), then press the green
   **Run ▶** button. Android Studio installs and launches سالار directly.
5. To get a shareable APK file: `Build → Build Bundle(s)/APK(s) → Build
   APK(s)`. The APK appears at
   `app/build/outputs/apk/debug/app-debug.apk`.

### Option B — Command line (Gradle)

```bash
cd SalarApp
gradle wrapper --gradle-version 8.4     # generates gradlew + the wrapper jar (one-time)
./gradlew assembleDebug                 # builds app/build/outputs/apk/debug/app-debug.apk
```

(You need a JDK 17 and the Android SDK command-line tools installed and
`ANDROID_HOME`/`ANDROID_SDK_ROOT` set for this option; Android Studio
handles all of that for you automatically, which is why Option A is
easier if you don't already have an Android dev setup.)

### Installing the APK on your phone

1. Copy `app-debug.apk` to your phone (USB cable, Bluetooth, or any file
   transfer app — no internet needed, no server involved).
2. On the phone, open the file with a file manager and tap **Install**.
   Android will warn about "installing from unknown sources" the first
   time — allow it for this file (Settings → Security, or the prompt
   itself will offer a shortcut).
3. Open **سالار** from the app drawer. That's it — no login, no network,
   no server ever contacted.

### Building a signed release APK (optional, for distributing widely)

In Android Studio: `Build → Generate Signed Bundle / APK → APK`, create
(or reuse) a keystore, and follow the wizard. A signed release APK
installs the same way as above.

## Where to extend next

- `DrawingView.DrawingTool.DIMENSION` → persist manual dimensions the same
  way walls/openings are persisted (add a `DimensionEntity` + DAO methods,
  mirroring `OpeningEntity`).
- `Simple3DView` → swap in `Filament` or `SceneView` if you want textured,
  lit 3D later; the wall/opening data model already has everything
  (position, thickness, height, door/window cutouts) a real 3D engine
  needs.
- `MaterialCalculator` → wire the 3D screen's per-wall height into the
  "from current plan" calculation instead of the current single default
  height.
- `ExportManager` → multi-page PDF for multi-floor plans.
