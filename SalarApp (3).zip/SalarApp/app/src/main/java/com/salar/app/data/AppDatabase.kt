package com.salar.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.salar.app.data.dao.DrawingDao
import com.salar.app.data.dao.ProjectDao
import com.salar.app.data.entity.*

/**
 * Local, on-device SQLite database (via Room). سالار never talks to a server -
 * every project, wall, room, opening, electrical/plumbing element and material
 * setting lives here so the app is fully usable offline forever.
 */
@Database(
    entities = [
        ProjectEntity::class,
        WallEntity::class,
        OpeningEntity::class,
        RoomFaceEntity::class,
        ElectricalItemEntity::class,
        WireRunEntity::class,
        PlumbingFixtureEntity::class,
        PipeRunEntity::class,
        MaterialSettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun drawingDao(): DrawingDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "salar.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
