package com.salar.app.calculation

import com.salar.app.data.entity.MaterialSettingsEntity
import com.salar.app.model.DrawingModel
import kotlin.math.ceil

data class ConcreteInput(
    val label: String,
    val lengthM: Float,
    val widthM: Float,
    val thicknessM: Float,
    val count: Int = 1
) {
    fun volumeM3(): Double = lengthM.toDouble() * widthM * thicknessM * count
}

data class QuantityResult(
    val wallAreaM2: Double,
    val wallVolumeM3: Double,
    val openingsAreaM2: Double,
    val netWallAreaM2: Double,
    val blockCount: Int,
    val concreteVolumeM3: Double,
    val cementBags: Double,
    val sandM3: Double,
    val aggregateM3: Double
)

/**
 * All ratios/constants come from [MaterialSettingsEntity], which the user can
 * edit per project (mix ratio, bag weight, block size, wastage factor, etc.)
 * so quantities match local practice - nothing here is hard-coded.
 */
class MaterialCalculator(private val settings: MaterialSettingsEntity) {

    /** Wall area/volume computed straight from the drawn 2D plan, openings deducted. */
    fun fromDrawing(model: DrawingModel): QuantityResult {
        var grossAreaM2 = 0.0
        var volumeM3 = 0.0
        val wallHeightM = 3.0 // default; overridden by per-wall height in the 3D screen if set

        for (wall in model.walls) {
            val lengthM = wall.lengthMM() / 1000.0
            val thicknessM = wall.thicknessMM / 1000.0
            grossAreaM2 += lengthM * wallHeightM
            volumeM3 += lengthM * thicknessM * wallHeightM
        }

        var openingsAreaM2 = 0.0
        for (opening in model.openings) {
            val widthM = opening.widthMM / 1000.0
            val heightM = opening.heightMM / 1000.0
            openingsAreaM2 += widthM * heightM
        }

        val netAreaM2 = (grossAreaM2 - openingsAreaM2).coerceAtLeast(0.0)
        return buildResult(netAreaM2, volumeM3)
    }

    /** Manual entry path: user types wall length/height/thickness + openings directly. */
    fun fromManualWall(
        lengthM: Double,
        heightM: Double,
        thicknessM: Double,
        openingsAreaM2: Double
    ): QuantityResult {
        val grossArea = lengthM * heightM
        val netArea = (grossArea - openingsAreaM2).coerceAtLeast(0.0)
        val volume = lengthM * thicknessM * heightM
        return buildResult(netArea, volume)
    }

    private fun buildResult(netWallAreaM2: Double, wallVolumeM3: Double): QuantityResult {
        val blockAreaM2 = (settings.blockLengthMM / 1000.0) * (settings.blockHeightMM / 1000.0)
        val blockCount = if (blockAreaM2 > 0) {
            ceil((netWallAreaM2 / blockAreaM2) * settings.mortarAllowanceFactor).toInt()
        } else 0

        return QuantityResult(
            wallAreaM2 = netWallAreaM2,
            wallVolumeM3 = wallVolumeM3,
            openingsAreaM2 = 0.0,
            netWallAreaM2 = netWallAreaM2,
            blockCount = blockCount,
            concreteVolumeM3 = 0.0,
            cementBags = 0.0,
            sandM3 = 0.0,
            aggregateM3 = 0.0
        )
    }

    /** Concrete (foundation / slab / column etc.) -> cement/sand/aggregate quantities. */
    fun concreteQuantities(inputs: List<ConcreteInput>): QuantityResult {
        val totalVolume = inputs.sumOf { it.volumeM3() }
        val dryVolume = totalVolume * settings.dryVolumeFactor
        val totalRatioParts = settings.cementRatio + settings.sandRatio + settings.aggregateRatio

        val cementVolume = dryVolume * (settings.cementRatio / totalRatioParts)
        val sandVolume = dryVolume * (settings.sandRatio / totalRatioParts)
        val aggregateVolume = dryVolume * (settings.aggregateRatio / totalRatioParts)

        // 1 bag of cement (50kg) ~= 0.0347 m3 loose volume; derive bags from
        // the editable bagsPerM3DryMix setting so it can be tuned locally.
        val cementBags = cementVolume * settings.cementBagsPerM3DryMix

        return QuantityResult(
            wallAreaM2 = 0.0,
            wallVolumeM3 = 0.0,
            openingsAreaM2 = 0.0,
            netWallAreaM2 = 0.0,
            blockCount = 0,
            concreteVolumeM3 = totalVolume,
            cementBags = cementBags,
            sandM3 = sandVolume,
            aggregateM3 = aggregateVolume
        )
    }

    companion object {
        val DEFAULT_CONCRETE_LABELS = listOf("Foundation", "Slab", "Column", "Beam")
    }
}
