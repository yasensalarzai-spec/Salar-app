package com.salar.app.drawing

/** Tools available on the 2D drawing screen (structure mode). */
enum class DrawingTool {
    SELECT,
    WALL,
    DOOR,
    WINDOW,
    DIMENSION,
    MOVE,
    DELETE
}

/** Tools available when the canvas is in electrical overlay mode. */
enum class ElectricalTool {
    SELECT,
    LIGHT,
    SWITCH,
    SOCKET,
    PANEL,
    WIRE,
    DELETE
}

/** Tools available when the canvas is in plumbing overlay mode. */
enum class PlumbingTool {
    SELECT,
    WATER_PIPE,
    DRAIN_PIPE,
    TOILET,
    SINK,
    SHOWER,
    TAP,
    DELETE
}

enum class CanvasMode { STRUCTURE, ELECTRICAL, PLUMBING }
