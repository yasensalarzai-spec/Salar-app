package com.salar.app.ui.drawing

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.salar.app.R
import com.salar.app.data.ProjectRepository
import com.salar.app.databinding.ActivityDrawingBinding
import com.salar.app.drawing.CanvasMode
import com.salar.app.drawing.DrawingTool
import com.salar.app.drawing.DrawingViewListener
import com.salar.app.ui.threeD.ThreeDActivity
import com.salar.app.utils.DisplayUnit
import com.salar.app.utils.Prefs
import kotlinx.coroutines.launch

class DrawingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDrawingBinding
    private lateinit var repository: ProjectRepository
    private var projectId: Long = -1L
    private var projectName: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDrawingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = ProjectRepository(this)

        projectId = intent.getLongExtra("project_id", Prefs.getLastProject(this))
        if (projectId == -1L) { finish(); return }
        Prefs.setLastProject(this, projectId)

        binding.drawingView.mode = CanvasMode.STRUCTURE
        binding.drawingView.displayUnit = DisplayUnit.valueOf(Prefs.getUnit(this))
        binding.drawingView.defaultWallThicknessMM = Prefs.getDefaultWallThickness(this)
        binding.drawingView.listener = object : DrawingViewListener {
            override fun onHistoryChanged(canUndo: Boolean, canRedo: Boolean) {
                binding.toolUndo.isEnabled = canUndo
                binding.toolRedo.isEnabled = canRedo
                binding.toolUndo.alpha = if (canUndo) 1f else 0.4f
                binding.toolRedo.alpha = if (canRedo) 1f else 0.4f
            }
            override fun onSelectionInfo(text: String?) {
                binding.textSelectionInfo.text = text ?: ""
                if (text != null && binding.drawingView.structureTool == DrawingTool.SELECT) {
                    offerWallEditDialog()
                }
            }
            override fun onWallDrawn(wallId: String, lengthMM: Float) {
                promptExactLength(wallId, lengthMM)
            }
        }

        setupToolbar()
        setupFloorSpinner()
        loadProject()
    }

    private fun loadProject() {
        lifecycleScope.launch {
            val project = repository.getProject(projectId) ?: return@launch
            projectName = project.name
            binding.textProjectTitle.text = project.name
            val model = repository.loadDrawing(projectId)
            binding.drawingView.setFloorCount(model.floorCount)
            binding.drawingView.setModel(model)
            refreshFloorSpinner(model.floorCount)
        }
    }

    private fun setupToolbar() {
        fun select(tool: DrawingTool) {
            binding.drawingView.structureTool = tool
            highlightTool(tool)
        }
        binding.toolWall.setOnClickListener { select(DrawingTool.WALL) }
        binding.toolDoor.setOnClickListener { select(DrawingTool.DOOR) }
        binding.toolWindow.setOnClickListener { select(DrawingTool.WINDOW) }
        binding.toolDimension.setOnClickListener { select(DrawingTool.DIMENSION) }
        binding.toolSelect.setOnClickListener { select(DrawingTool.SELECT) }
        binding.toolMove.setOnClickListener { select(DrawingTool.MOVE) }
        binding.toolDelete.setOnClickListener { select(DrawingTool.DELETE) }
        binding.toolUndo.setOnClickListener { binding.drawingView.undo() }
        binding.toolRedo.setOnClickListener { binding.drawingView.redo() }
        binding.toolZoomIn.setOnClickListener { binding.drawingView.zoomIn() }
        binding.toolZoomOut.setOnClickListener { binding.drawingView.zoomOut() }
        binding.toolSave.setOnClickListener { saveProject() }
        binding.btnGoto3D.setOnClickListener {
            saveProject()
            startActivity(Intent(this, ThreeDActivity::class.java).putExtra("project_id", projectId))
        }
        highlightTool(DrawingTool.WALL)
    }

    private fun highlightTool(tool: DrawingTool) {
        val map = mapOf(
            DrawingTool.WALL to binding.toolWall,
            DrawingTool.DOOR to binding.toolDoor,
            DrawingTool.WINDOW to binding.toolWindow,
            DrawingTool.DIMENSION to binding.toolDimension,
            DrawingTool.SELECT to binding.toolSelect,
            DrawingTool.MOVE to binding.toolMove,
            DrawingTool.DELETE to binding.toolDelete
        )
        map.values.forEach { it.isSelected = false }
        map[tool]?.isSelected = true
    }

    private fun setupFloorSpinner() {
        binding.spinnerFloor.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                binding.drawingView.setActiveFloor(position)
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        binding.btnAddFloor.setOnClickListener {
            val newCount = (binding.spinnerFloor.adapter?.count ?: 1) + 1
            binding.drawingView.setFloorCount(newCount)
            refreshFloorSpinner(newCount)
            binding.spinnerFloor.setSelection(newCount - 1)
        }
    }

    private fun refreshFloorSpinner(count: Int) {
        val labels = (1..count).map { "${getString(R.string.floors)} $it" }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerFloor.adapter = adapter
    }

    private fun promptExactLength(wallId: String, currentLengthMM: Float) {
        val unit = binding.drawingView.displayUnit
        val currentValue = com.salar.app.utils.UnitConverter.fromMM(currentLengthMM, unit)
        val dialogView = layoutInflater.inflate(R.layout.dialog_text_input, null)
        val edit = dialogView.findViewById<EditText>(R.id.editValue)
        edit.setText(String.format("%.2f", currentValue))

        AlertDialog.Builder(this)
            .setTitle(R.string.wall_length_dialog_title)
            .setView(dialogView)
            .setPositiveButton(R.string.apply) { _, _ ->
                val entered = edit.text.toString().toFloatOrNull() ?: return@setPositiveButton
                val mm = com.salar.app.utils.UnitConverter.toMM(entered, unit)
                binding.drawingView.setSelectedWallId(wallId)
                binding.drawingView.setSelectedWallExactLength(mm)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun offerWallEditDialog() {
        val wallId = binding.drawingView.getSelectedWallId() ?: return
        val wall = binding.drawingView.setWallByWallId(wallId) ?: return
        val unit = binding.drawingView.displayUnit

        val options = arrayOf(
            getString(R.string.wall_length_dialog_title),
            getString(R.string.wall_thickness_dialog_title)
        )
        AlertDialog.Builder(this)
            .setItems(options) { _, which ->
                if (which == 0) {
                    promptExactLength(wallId, wall.lengthMM())
                } else {
                    val dialogView = layoutInflater.inflate(R.layout.dialog_text_input, null)
                    val edit = dialogView.findViewById<EditText>(R.id.editValue)
                    edit.setText(String.format("%.0f", wall.thicknessMM))
                    AlertDialog.Builder(this)
                        .setTitle(R.string.wall_thickness_dialog_title)
                        .setView(dialogView)
                        .setPositiveButton(R.string.apply) { _, _ ->
                            val mm = edit.text.toString().toFloatOrNull() ?: return@setPositiveButton
                            binding.drawingView.setSelectedWallThickness(mm)
                        }
                        .setNegativeButton(R.string.cancel, null)
                        .show()
                }
            }
            .show()
    }

    private fun saveProject() {
        lifecycleScope.launch {
            repository.saveDrawing(projectId, binding.drawingView.getModel())
        }
    }

    override fun onPause() {
        super.onPause()
        saveProject() // auto-save whenever the user leaves this screen
    }
}
